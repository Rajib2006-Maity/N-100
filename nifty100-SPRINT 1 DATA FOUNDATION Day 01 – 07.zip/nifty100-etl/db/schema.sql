-- =====================================================================
-- nifty100.db schema
-- Sprint 1 · Day 04 — SQLite Database Schema
-- 11 tables (companies, profitandloss, balancesheet, cashflow, analysis,
-- documents, prosandcons, sectors, stock_prices, financial_ratios,
-- peer_groups) with PK / FK constraints. Foreign keys are enforced by
-- the loader via `PRAGMA foreign_keys = ON;`
-- =====================================================================

PRAGMA foreign_keys = ON;

-- ---------------------------------------------------------------------
-- 1. sectors  (parent table — no dependencies)
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS sectors (
    sector_id     INTEGER PRIMARY KEY AUTOINCREMENT,
    sector_code   TEXT NOT NULL UNIQUE,
    sector_name   TEXT NOT NULL
);

-- ---------------------------------------------------------------------
-- 2. companies  (parent table — references sectors)
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS companies (
    company_id            INTEGER PRIMARY KEY AUTOINCREMENT,
    ticker                TEXT NOT NULL UNIQUE,
    company_name          TEXT NOT NULL,
    isin                  TEXT,
    sector_id             INTEGER NOT NULL,
    listing_date          TEXT,
    market_cap_category   TEXT CHECK (market_cap_category IN ('LARGE','MID','SMALL') OR market_cap_category IS NULL),
    FOREIGN KEY (sector_id) REFERENCES sectors (sector_id)
);

-- ---------------------------------------------------------------------
-- 3. profitandloss  (child of companies)
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS profitandloss (
    pl_id               INTEGER PRIMARY KEY AUTOINCREMENT,
    company_id          INTEGER NOT NULL,
    year                INTEGER NOT NULL,
    sales               REAL,
    expenses            REAL,
    operating_profit    REAL,
    opm_percent         REAL,
    other_income        REAL,
    depreciation        REAL,
    interest            REAL,
    profit_before_tax   REAL,
    tax                 REAL,
    net_profit           REAL,
    eps                 REAL,
    UNIQUE (company_id, year),
    FOREIGN KEY (company_id) REFERENCES companies (company_id)
);

-- ---------------------------------------------------------------------
-- 4. balancesheet  (child of companies)
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS balancesheet (
    bs_id                INTEGER PRIMARY KEY AUTOINCREMENT,
    company_id           INTEGER NOT NULL,
    year                 INTEGER NOT NULL,
    equity_capital       REAL,
    reserves             REAL,
    borrowings           REAL,
    other_liabilities    REAL,
    total_liabilities    REAL,
    fixed_assets         REAL,
    cwip                 REAL,
    investments          REAL,
    other_assets         REAL,
    total_assets         REAL,
    UNIQUE (company_id, year),
    FOREIGN KEY (company_id) REFERENCES companies (company_id)
);

-- ---------------------------------------------------------------------
-- 5. cashflow  (child of companies)
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS cashflow (
    cf_id                    INTEGER PRIMARY KEY AUTOINCREMENT,
    company_id               INTEGER NOT NULL,
    year                     INTEGER NOT NULL,
    cash_from_operating      REAL,
    cash_from_investing      REAL,
    cash_from_financing      REAL,
    net_cash_flow            REAL,
    UNIQUE (company_id, year),
    FOREIGN KEY (company_id) REFERENCES companies (company_id)
);

-- ---------------------------------------------------------------------
-- 6. stock_prices  (child of companies)
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS stock_prices (
    price_id      INTEGER PRIMARY KEY AUTOINCREMENT,
    company_id    INTEGER NOT NULL,
    price_date    TEXT NOT NULL,
    open          REAL,
    high          REAL,
    low           REAL,
    close         REAL,
    volume        INTEGER,
    UNIQUE (company_id, price_date),
    FOREIGN KEY (company_id) REFERENCES companies (company_id)
);

-- ---------------------------------------------------------------------
-- 7. financial_ratios  (child of companies — populated by `make ratios`,
--    derived from profitandloss / balancesheet / cashflow, not loaded
--    directly from a raw source file)
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS financial_ratios (
    ratio_id        INTEGER PRIMARY KEY AUTOINCREMENT,
    company_id      INTEGER NOT NULL,
    year            INTEGER NOT NULL,
    roce_percent    REAL,
    roe_percent     REAL,
    debt_to_equity  REAL,
    current_ratio   REAL,
    UNIQUE (company_id, year),
    FOREIGN KEY (company_id) REFERENCES companies (company_id)
);

-- ---------------------------------------------------------------------
-- 8. analysis  (child of companies — qualitative / quantitative notes
--    sourced from analysis_notes.xlsx, shareholding_pattern.xlsx and
--    corporate_actions.xlsx)
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS analysis (
    analysis_id    INTEGER PRIMARY KEY AUTOINCREMENT,
    company_id     INTEGER NOT NULL,
    metric_name    TEXT NOT NULL,
    metric_value   TEXT,
    as_of_date     TEXT,
    source_file    TEXT,
    FOREIGN KEY (company_id) REFERENCES companies (company_id)
);

-- ---------------------------------------------------------------------
-- 9. documents  (child of companies)
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS documents (
    doc_id        INTEGER PRIMARY KEY AUTOINCREMENT,
    company_id    INTEGER NOT NULL,
    doc_type      TEXT,
    doc_url       TEXT,
    doc_date      TEXT,
    FOREIGN KEY (company_id) REFERENCES companies (company_id)
);

-- ---------------------------------------------------------------------
-- 10. prosandcons  (child of companies)
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS prosandcons (
    pac_id        INTEGER PRIMARY KEY AUTOINCREMENT,
    company_id    INTEGER NOT NULL,
    type          TEXT CHECK (type IN ('PRO','CON')),
    description   TEXT NOT NULL,
    FOREIGN KEY (company_id) REFERENCES companies (company_id)
);

-- ---------------------------------------------------------------------
-- 11. peer_groups  (child of companies, self-referencing — both
--     company_id and peer_company_id point back to companies)
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS peer_groups (
    peer_id            INTEGER PRIMARY KEY AUTOINCREMENT,
    company_id         INTEGER NOT NULL,
    peer_company_id    INTEGER NOT NULL,
    sector_id          INTEGER NOT NULL,
    UNIQUE (company_id, peer_company_id),
    FOREIGN KEY (company_id) REFERENCES companies (company_id),
    FOREIGN KEY (peer_company_id) REFERENCES companies (company_id),
    FOREIGN KEY (sector_id) REFERENCES sectors (sector_id)
);

-- ---------------------------------------------------------------------
-- Helpful indexes for FK lookups (PK indexes are implicit)
-- ---------------------------------------------------------------------
CREATE INDEX IF NOT EXISTS idx_pl_company        ON profitandloss (company_id);
CREATE INDEX IF NOT EXISTS idx_bs_company        ON balancesheet (company_id);
CREATE INDEX IF NOT EXISTS idx_cf_company         ON cashflow (company_id);
CREATE INDEX IF NOT EXISTS idx_sp_company         ON stock_prices (company_id);
CREATE INDEX IF NOT EXISTS idx_fr_company         ON financial_ratios (company_id);
CREATE INDEX IF NOT EXISTS idx_an_company         ON analysis (company_id);
CREATE INDEX IF NOT EXISTS idx_doc_company        ON documents (company_id);
CREATE INDEX IF NOT EXISTS idx_pac_company        ON prosandcons (company_id);
CREATE INDEX IF NOT EXISTS idx_peer_company       ON peer_groups (company_id);
CREATE INDEX IF NOT EXISTS idx_companies_sector   ON companies (sector_id);
