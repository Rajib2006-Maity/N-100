"""
src/etl/compute_ratios.py
Backs the `make ratios` Makefile target.

financial_ratios is intentionally NOT loaded from a raw source file —
it is derived from profitandloss / balancesheet / cashflow once those
are already in nifty100.db. This script computes, per (company_id, year)
where both P&L and BS data exist for that year:

    ROCE %          = operating_profit / capital_employed * 100
                       (capital_employed = total_assets - other_liabilities)
    ROE %           = net_profit / (equity_capital + reserves) * 100
    Debt-to-Equity   = borrowings / (equity_capital + reserves)
    Current ratio    = other_assets / other_liabilities  (proxy, since the
                        synthetic schema does not separately split current
                        vs non-current assets/liabilities)
"""

from __future__ import annotations

import os
import sqlite3
from pathlib import Path

from dotenv import load_dotenv

load_dotenv()

PROJECT_ROOT = Path(__file__).resolve().parents[2]
DB_PATH = PROJECT_ROOT / os.getenv("DB_PATH", "nifty100.db")


def compute_and_load_ratios(db_path: Path = DB_PATH) -> int:
    conn = sqlite3.connect(db_path)
    conn.execute("PRAGMA foreign_keys = ON;")

    conn.execute("DELETE FROM financial_ratios;")

    rows = conn.execute(
        """
        SELECT
            p.company_id, p.year, p.operating_profit, p.net_profit,
            b.equity_capital, b.reserves, b.borrowings,
            b.total_assets, b.other_liabilities, b.other_assets
        FROM profitandloss p
        JOIN balancesheet b ON p.company_id = b.company_id AND p.year = b.year
        """
    ).fetchall()

    n_loaded = 0
    for (company_id, year, op_profit, net_profit, equity_capital, reserves,
         borrowings, total_assets, other_liabilities, other_assets) in rows:

        equity_base = (equity_capital or 0) + (reserves or 0)
        capital_employed = (total_assets or 0) - (other_liabilities or 0)

        roce = round(op_profit / capital_employed * 100, 2) if capital_employed else None
        roe = round(net_profit / equity_base * 100, 2) if equity_base else None
        d_to_e = round(borrowings / equity_base, 3) if equity_base else None
        current_ratio = round(other_assets / other_liabilities, 3) if other_liabilities else None

        conn.execute(
            """INSERT OR REPLACE INTO financial_ratios
               (company_id, year, roce_percent, roe_percent, debt_to_equity, current_ratio)
               VALUES (?, ?, ?, ?, ?, ?)""",
            (company_id, year, roce, roe, d_to_e, current_ratio),
        )
        n_loaded += 1

    conn.commit()
    conn.close()
    return n_loaded


if __name__ == "__main__":
    n = compute_and_load_ratios()
    print(f"financial_ratios computed for {n} (company_id, year) pairs")
