"""
src/etl/normaliser.py
Sprint 1 · Day 02 — Excel Loader & Normaliser

Pure, side-effect-free normalisation helpers used by loader.py before
any row is written to SQLite. Keeping these as small pure functions
makes them trivial to unit test in isolation (see tests/etl/test_normaliser.py).
"""

from __future__ import annotations

import re
from datetime import datetime

# ---------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------

CURRENT_YEAR = datetime.now().year
MIN_VALID_YEAR = 1990
MAX_VALID_YEAR = CURRENT_YEAR + 1  # allow next FY to be entered slightly early

# Indian exchange suffixes commonly appended to tickers in source files
_TICKER_SUFFIXES = (".NS", ".BO", ".NSE", ".BSE")

# A valid NSE/BSE-style ticker: 1-20 chars, letters/digits/&/-
_TICKER_RE = re.compile(r"^[A-Z0-9&\-]{1,20}$")

# Matches "FY23", "FY 2023", "FY2023-24", "FY 23-24"
_FY_RE = re.compile(r"^FY\s*-?\s*(\d{2,4})(?:\s*-\s*(\d{2,4}))?$", re.IGNORECASE)

# Matches "2022-23", "2022/23"
_RANGE_RE = re.compile(r"^(\d{4})\s*[-/]\s*(\d{2,4})$")

# Matches month-year like "Mar-23", "March 2023", "Mar 2023"
_MONTH_YEAR_RE = re.compile(
    r"^(jan|feb|mar|apr|may|jun|jul|aug|sep|sept|oct|nov|dec)[a-z]*[\s\-]+(\d{2,4})$",
    re.IGNORECASE,
)


class NormalisationError(ValueError):
    """Raised when a raw source value cannot be safely normalised."""


# ---------------------------------------------------------------------
# normalize_year
# ---------------------------------------------------------------------

def normalize_year(raw_value) -> int:
    """
    Normalise a wide variety of year representations found across the
    12 source Excel files into a single 4-digit calendar year (int).

    Accepted forms include (non-exhaustive):
        2023, 2023.0, "2023"
        "FY23", "FY 2023", "FY23-24", "FY 2023-24"
        "2022-23", "2022/23"
        "Mar-23", "March 2023", "Mar 2023"

    For financial-year ranges (e.g. "FY23-24" or "2022-23"), the
    *ending* calendar year is returned, matching screener.in / NSE
    convention where "FY24" / "2023-24" refers to the year ending
    March 2024.

    Raises NormalisationError if the value cannot be parsed or falls
    outside [MIN_VALID_YEAR, MAX_VALID_YEAR].
    """
    if raw_value is None:
        raise NormalisationError("year value is None")

    # --- numeric types -------------------------------------------------
    if isinstance(raw_value, (int, float)):
        if isinstance(raw_value, float) and raw_value.is_integer():
            year = int(raw_value)
        elif isinstance(raw_value, int):
            year = raw_value
        else:
            raise NormalisationError(f"non-integer float year: {raw_value!r}")
        return _validate_year_range(year)

    if not isinstance(raw_value, str):
        raise NormalisationError(f"unsupported year type: {type(raw_value)!r}")

    text = raw_value.strip()
    if text == "":
        raise NormalisationError("empty year string")

    # --- plain 4-digit year ---------------------------------------------
    if text.isdigit():
        return _validate_year_range(int(text))

    # --- "FY23", "FY 2023", "FY23-24" -----------------------------------
    m = _FY_RE.match(text)
    if m:
        first, second = m.group(1), m.group(2)
        year_token = second if second else first
        return _validate_year_range(_expand_2digit(year_token))

    # --- "2022-23", "2022/23" --------------------------------------------
    m = _RANGE_RE.match(text)
    if m:
        end_token = m.group(2)
        return _validate_year_range(_expand_2digit(end_token))

    # --- "Mar-23", "March 2023" -------------------------------------------
    m = _MONTH_YEAR_RE.match(text)
    if m:
        return _validate_year_range(_expand_2digit(m.group(2)))

    raise NormalisationError(f"unrecognised year format: {raw_value!r}")


def _expand_2digit(token: str) -> int:
    """Expand a 2-digit year token ('23') to 4 digits (2023); pass through 4-digit tokens."""
    token = token.strip()
    if len(token) == 4:
        return int(token)
    if len(token) == 2:
        n = int(token)
        # Pivot: 00-49 -> 2000-2049, 50-99 -> 1950-1999
        return 2000 + n if n <= 49 else 1900 + n
    raise NormalisationError(f"unexpected year token length: {token!r}")


def _validate_year_range(year: int) -> int:
    if year < MIN_VALID_YEAR or year > MAX_VALID_YEAR:
        raise NormalisationError(
            f"year {year} outside valid range [{MIN_VALID_YEAR}, {MAX_VALID_YEAR}]"
        )
    return year


# ---------------------------------------------------------------------
# normalize_ticker
# ---------------------------------------------------------------------

def normalize_ticker(raw_value) -> str:
    """
    Normalise a raw ticker string into the canonical uppercase form
    used as the natural key for the `companies` table.

    Steps:
        1. Type/empty check
        2. Strip whitespace
        3. Uppercase
        4. Strip known exchange suffixes (.NS, .BO, .NSE, .BSE)
        5. Collapse internal whitespace
        6. Validate against the allowed ticker character set

    Raises NormalisationError on invalid input.
    """
    if raw_value is None:
        raise NormalisationError("ticker value is None")

    if not isinstance(raw_value, str):
        raise NormalisationError(f"unsupported ticker type: {type(raw_value)!r}")

    text = raw_value.strip()
    if text == "":
        raise NormalisationError("empty ticker string")

    text = text.upper()

    # collapse internal whitespace (e.g. "TATA MOTORS" -> not a real ticker,
    # but guards against stray spaces like "TCS " -> "TCS")
    text = re.sub(r"\s+", "", text)

    for suffix in _TICKER_SUFFIXES:
        if text.endswith(suffix):
            text = text[: -len(suffix)]
            break

    if text == "":
        raise NormalisationError(f"ticker empty after suffix stripping: {raw_value!r}")

    if not _TICKER_RE.match(text):
        raise NormalisationError(f"ticker fails format validation: {raw_value!r} -> {text!r}")

    return text


# ---------------------------------------------------------------------
# Small additional normalisers used by loader.py / validator.py
# ---------------------------------------------------------------------

def normalize_numeric(raw_value):
    """Coerce a raw numeric-ish cell (which may contain commas, '-', blanks) to float or None."""
    if raw_value is None:
        return None
    if isinstance(raw_value, (int, float)):
        return float(raw_value)
    text = str(raw_value).strip()
    if text in ("", "-", "NA", "N/A", "nan", "NaN"):
        return None
    text = text.replace(",", "")
    try:
        return float(text)
    except ValueError:
        raise NormalisationError(f"cannot coerce numeric value: {raw_value!r}")


def normalize_url(raw_value):
    """Lightly normalise a URL string (strip whitespace); does not validate format here —
    URL format validation is handled by DQ-10 in validator.py."""
    if raw_value is None:
        return None
    text = str(raw_value).strip()
    return text or None
