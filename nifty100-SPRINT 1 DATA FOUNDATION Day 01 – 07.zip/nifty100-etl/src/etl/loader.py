"""
src/etl/loader.py
Sprint 1 · Day 02 (Excel loader) + Day 04 (SQLite schema wiring) + Day 05 (full load)

Reads the 12 raw source Excel files (7 core + 5 supplementary) from
RAW_DATA_DIR, normalises key fields via normaliser.py, and loads them
into nifty100.db following dependency order:

    1. sectors            (parent)
    2. companies           (depends on sectors)
    3. profitandloss        (depends on companies)
    4. balancesheet          (depends on companies)
    5. cashflow              (depends on companies)
    6. stock_prices           (depends on companies)
    7. analysis                (depends on companies; fed by 3 supplementary files)
    8. documents                 (depends on companies)
    9. prosandcons                (depends on companies)
   10. peer_groups                 (depends on companies, self-referencing)

financial_ratios is intentionally NOT populated here — it is derived
from already-loaded data by `src/etl/compute_ratios.py` (the `make
ratios` target), since ratios are computed, not sourced raw.

Writes output/load_audit.csv with one row per source file: rows read,
rows loaded, rows rejected, and a free-text note. A CRITICAL rejection
in any core file should block Day 05 sign-off per the sprint's exit
criteria.
"""

from __future__ import annotations

import os
import sqlite3
from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional

import pandas as pd
from dotenv import load_dotenv

from src.etl.normaliser import (
    NormalisationError,
    normalize_numeric,
    normalize_ticker,
    normalize_url,
    normalize_year,
)

load_dotenv()

PROJECT_ROOT = Path(__file__).resolve().parents[2]
RAW_DATA_DIR = PROJECT_ROOT / os.getenv("RAW_DATA_DIR", "data/raw")
DB_PATH = PROJECT_ROOT / os.getenv("DB_PATH", "nifty100.db")
OUTPUT_DIR = PROJECT_ROOT / os.getenv("OUTPUT_DIR", "output")
SCHEMA_PATH = PROJECT_ROOT / "db" / "schema.sql"


@dataclass
class AuditRow:
    source_file: str
    target_table: str
    rows_read: int
    rows_loaded: int
    rows_rejected: int
    notes: str = ""


def get_connection(db_path: Path = DB_PATH) -> sqlite3.Connection:
    conn = sqlite3.connect(db_path)
    conn.execute("PRAGMA foreign_keys = ON;")
    return conn


def init_schema(conn: sqlite3.Connection) -> None:
    sql = SCHEMA_PATH.read_text()
    conn.executescript(sql)
    conn.commit()


def _read_excel(filename: str) -> pd.DataFrame:
    path = RAW_DATA_DIR / filename
    if not path.exists():
        raise FileNotFoundError(f"Expected source file not found: {path}")
    return pd.read_excel(path)


# ---------------------------------------------------------------------
# Per-table loaders. Each returns an AuditRow describing the outcome.
# ---------------------------------------------------------------------

def load_sectors(conn) -> AuditRow:
    df = _read_excel("sectors.xlsx")
    rows_read = len(df)
    loaded, rejected = 0, 0
    for _, r in df.iterrows():
        try:
            conn.execute(
                "INSERT OR IGNORE INTO sectors (sector_code, sector_name) VALUES (?, ?)",
                (str(r["sector_code"]).strip(), str(r["sector_name"]).strip()),
            )
            loaded += 1
        except sqlite3.Error:
            rejected += 1
    conn.commit()
    return AuditRow("sectors.xlsx", "sectors", rows_read, loaded, rejected)


def load_companies(conn) -> AuditRow:
    df = _read_excel("companies_master.xlsx")
    rows_read = len(df)
    sector_map = dict(conn.execute("SELECT sector_code, sector_id FROM sectors").fetchall())
    loaded, rejected = 0, 0
    rejection_notes = []
    for _, r in df.iterrows():
        try:
            ticker = normalize_ticker(r["ticker"])
            sector_id = sector_map.get(str(r["sector_code"]).strip())
            if sector_id is None:
                raise NormalisationError(f"unknown sector_code: {r['sector_code']!r}")
            conn.execute(
                """INSERT OR IGNORE INTO companies
                   (ticker, company_name, isin, sector_id, listing_date, market_cap_category)
                   VALUES (?, ?, ?, ?, ?, ?)""",
                (
                    ticker,
                    str(r["company_name"]).strip(),
                    str(r["isin"]).strip() if pd.notna(r["isin"]) else None,
                    sector_id,
                    str(r["listing_date"]) if pd.notna(r["listing_date"]) else None,
                    str(r["market_cap_category"]) if pd.notna(r["market_cap_category"]) else None,
                ),
            )
            loaded += 1
        except (NormalisationError, sqlite3.Error) as e:
            rejected += 1
            rejection_notes.append(str(e))
    conn.commit()
    notes = f"{rejected} rejected: {rejection_notes[:3]}" if rejection_notes else ""
    return AuditRow("companies_master.xlsx", "companies", rows_read, loaded, rejected, notes)


def _company_id_lookup(conn) -> dict:
    """Map the synthetic source-file company_id_src -> real companies.company_id via ticker."""
    rows = conn.execute("SELECT ticker, company_id FROM companies").fetchall()
    return {ticker: cid for ticker, cid in rows}


def _src_ticker_map(companies_raw: pd.DataFrame) -> dict:
    """Map company_id_src (raw) -> normalised ticker, so child files (keyed by
    company_id_src + raw ticker) can be joined to the already-loaded companies table."""
    out = {}
    for _, r in companies_raw.iterrows():
        try:
            out[r["company_id_src"]] = normalize_ticker(r["ticker"])
        except NormalisationError:
            continue
    return out


def load_yearly_table(conn, filename: str, table: str, value_cols: list[str], src_to_ticker: dict, ticker_to_id: dict) -> AuditRow:
    df = _read_excel(filename)
    rows_read = len(df)
    loaded, rejected = 0, 0
    notes = []
    col_list = ", ".join(["company_id", "year"] + value_cols)
    placeholders = ", ".join(["?"] * (2 + len(value_cols)))
    sql = f"INSERT OR IGNORE INTO {table} ({col_list}) VALUES ({placeholders})"

    for _, r in df.iterrows():
        try:
            ticker = src_to_ticker.get(r["company_id_src"])
            company_id = ticker_to_id.get(ticker)
            if company_id is None:
                raise NormalisationError(f"no matching company for company_id_src={r['company_id_src']!r}")
            year = normalize_year(r["year_label"])
            values = [company_id, year]
            for col in value_cols:
                values.append(normalize_numeric(r[col]))
            conn.execute(sql, values)
            loaded += 1
        except (NormalisationError, sqlite3.Error) as e:
            rejected += 1
            if len(notes) < 3:
                notes.append(str(e))
    conn.commit()
    return AuditRow(filename, table, rows_read, loaded, rejected, "; ".join(notes))


def load_stock_prices(conn, src_to_ticker: dict, ticker_to_id: dict) -> AuditRow:
    df = _read_excel("stock_prices.xlsx")
    rows_read = len(df)
    loaded, rejected = 0, 0
    for _, r in df.iterrows():
        try:
            ticker = src_to_ticker.get(r["company_id_src"])
            company_id = ticker_to_id.get(ticker)
            if company_id is None:
                raise NormalisationError("no matching company")
            conn.execute(
                """INSERT OR IGNORE INTO stock_prices
                   (company_id, price_date, open, high, low, close, volume)
                   VALUES (?, ?, ?, ?, ?, ?, ?)""",
                (
                    company_id,
                    str(r["price_date"]),
                    normalize_numeric(r["open"]),
                    normalize_numeric(r["high"]),
                    normalize_numeric(r["low"]),
                    normalize_numeric(r["close"]),
                    int(r["volume"]) if pd.notna(r["volume"]) else None,
                ),
            )
            loaded += 1
        except (NormalisationError, sqlite3.Error, ValueError):
            rejected += 1
    conn.commit()
    return AuditRow("stock_prices.xlsx", "stock_prices", rows_read, loaded, rejected)


def load_analysis_sources(conn, src_to_ticker: dict, ticker_to_id: dict) -> list[AuditRow]:
    audits = []

    # analysis_notes.xlsx
    df = _read_excel("analysis_notes.xlsx")
    loaded, rejected = 0, 0
    for _, r in df.iterrows():
        cid = ticker_to_id.get(src_to_ticker.get(r["company_id_src"]))
        if cid is None:
            rejected += 1
            continue
        conn.execute(
            "INSERT INTO analysis (company_id, metric_name, metric_value, as_of_date, source_file) VALUES (?, ?, ?, ?, ?)",
            (cid, "analyst_note", str(r["note"]), str(r["as_of_date"]), "analysis_notes.xlsx"),
        )
        loaded += 1
    conn.commit()
    audits.append(AuditRow("analysis_notes.xlsx", "analysis", len(df), loaded, rejected))

    # shareholding_pattern.xlsx
    df = _read_excel("shareholding_pattern.xlsx")
    loaded, rejected = 0, 0
    for _, r in df.iterrows():
        cid = ticker_to_id.get(src_to_ticker.get(r["company_id_src"]))
        if cid is None:
            rejected += 1
            continue
        for metric in ("promoter_holding_pct", "fii_holding_pct", "dii_holding_pct", "public_holding_pct"):
            conn.execute(
                "INSERT INTO analysis (company_id, metric_name, metric_value, as_of_date, source_file) VALUES (?, ?, ?, ?, ?)",
                (cid, metric, str(r[metric]), str(r["as_of_date"]), "shareholding_pattern.xlsx"),
            )
        loaded += 1
    conn.commit()
    audits.append(AuditRow("shareholding_pattern.xlsx", "analysis", len(df), loaded, rejected))

    # corporate_actions.xlsx
    df = _read_excel("corporate_actions.xlsx")
    loaded, rejected = 0, 0
    for _, r in df.iterrows():
        cid = ticker_to_id.get(src_to_ticker.get(r["company_id_src"]))
        if cid is None:
            rejected += 1
            continue
        conn.execute(
            "INSERT INTO analysis (company_id, metric_name, metric_value, as_of_date, source_file) VALUES (?, ?, ?, ?, ?)",
            (cid, f"corporate_action:{r['action_type']}", str(r["action_value"]), str(r["ex_date"]), "corporate_actions.xlsx"),
        )
        loaded += 1
    conn.commit()
    audits.append(AuditRow("corporate_actions.xlsx", "analysis", len(df), loaded, rejected))

    return audits


def load_documents(conn, src_to_ticker: dict, ticker_to_id: dict) -> AuditRow:
    df = _read_excel("company_documents.xlsx")
    loaded, rejected = 0, 0
    for _, r in df.iterrows():
        cid = ticker_to_id.get(src_to_ticker.get(r["company_id_src"]))
        if cid is None:
            rejected += 1
            continue
        conn.execute(
            "INSERT INTO documents (company_id, doc_type, doc_url, doc_date) VALUES (?, ?, ?, ?)",
            (cid, str(r["doc_type"]), normalize_url(r["doc_url"]), str(r["doc_date"])),
        )
        loaded += 1
    conn.commit()
    return AuditRow("company_documents.xlsx", "documents", len(df), loaded, rejected)


def load_pros_and_cons(conn, src_to_ticker: dict, ticker_to_id: dict) -> AuditRow:
    df = _read_excel("pros_and_cons.xlsx")
    loaded, rejected = 0, 0
    for _, r in df.iterrows():
        cid = ticker_to_id.get(src_to_ticker.get(r["company_id_src"]))
        if cid is None:
            rejected += 1
            continue
        conn.execute(
            "INSERT INTO prosandcons (company_id, type, description) VALUES (?, ?, ?)",
            (cid, str(r["type"]), str(r["description"])),
        )
        loaded += 1
    conn.commit()
    return AuditRow("pros_and_cons.xlsx", "prosandcons", len(df), loaded, rejected)


def load_peer_groups(conn, src_to_ticker: dict, ticker_to_id: dict) -> AuditRow:
    df = _read_excel("peer_groups.xlsx")
    sector_map = dict(conn.execute("SELECT sector_code, sector_id FROM sectors").fetchall())
    loaded, rejected = 0, 0
    for _, r in df.iterrows():
        cid = ticker_to_id.get(src_to_ticker.get(r["company_id_src"]))
        pid = ticker_to_id.get(src_to_ticker.get(r["peer_company_id_src"]))
        sid = sector_map.get(str(r["sector_code"]).strip())
        if cid is None or pid is None or sid is None:
            rejected += 1
            continue
        conn.execute(
            "INSERT OR IGNORE INTO peer_groups (company_id, peer_company_id, sector_id) VALUES (?, ?, ?)",
            (cid, pid, sid),
        )
        loaded += 1
    conn.commit()
    return AuditRow("peer_groups.xlsx", "peer_groups", len(df), loaded, rejected)


# ---------------------------------------------------------------------
# Orchestration
# ---------------------------------------------------------------------

def run_full_load(db_path: Path = DB_PATH) -> list[AuditRow]:
    """Run the Day 05 full load across all 12 files in dependency order.
    Returns the list of AuditRow results (also written to load_audit.csv)."""
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)

    # start from a clean database each full load, per Day 05 "full reload" semantics
    if db_path.exists():
        db_path.unlink()

    conn = get_connection(db_path)
    init_schema(conn)

    audits: list[AuditRow] = []

    audits.append(load_sectors(conn))
    audits.append(load_companies(conn))

    companies_raw = _read_excel("companies_master.xlsx")
    src_to_ticker = _src_ticker_map(companies_raw)
    ticker_to_id = _company_id_lookup(conn)

    audits.append(load_yearly_table(
        conn, "profit_and_loss.xlsx", "profitandloss",
        ["sales", "expenses", "operating_profit", "opm_percent", "other_income",
         "depreciation", "interest", "profit_before_tax", "tax", "net_profit", "eps"],
        src_to_ticker, ticker_to_id,
    ))
    audits.append(load_yearly_table(
        conn, "balance_sheet.xlsx", "balancesheet",
        ["equity_capital", "reserves", "borrowings", "other_liabilities", "total_liabilities",
         "fixed_assets", "cwip", "investments", "other_assets", "total_assets"],
        src_to_ticker, ticker_to_id,
    ))
    audits.append(load_yearly_table(
        conn, "cash_flow.xlsx", "cashflow",
        ["cash_from_operating", "cash_from_investing", "cash_from_financing", "net_cash_flow"],
        src_to_ticker, ticker_to_id,
    ))
    audits.append(load_stock_prices(conn, src_to_ticker, ticker_to_id))
    audits.extend(load_analysis_sources(conn, src_to_ticker, ticker_to_id))
    audits.append(load_documents(conn, src_to_ticker, ticker_to_id))
    audits.append(load_pros_and_cons(conn, src_to_ticker, ticker_to_id))
    audits.append(load_peer_groups(conn, src_to_ticker, ticker_to_id))

    fk_violations = conn.execute("PRAGMA foreign_key_check;").fetchall()
    conn.close()

    write_load_audit(audits, fk_violations)
    return audits


def write_load_audit(audits: list[AuditRow], fk_violations: list) -> None:
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    df = pd.DataFrame([a.__dict__ for a in audits])
    df["severity"] = df["rows_rejected"].apply(lambda n: "CRITICAL" if n > 0 else "OK")
    df.to_csv(OUTPUT_DIR / "load_audit.csv", index=False)

    summary_path = OUTPUT_DIR / "load_audit_summary.txt"
    with open(summary_path, "w") as f:
        f.write(f"Total files processed : {len(audits)}\n")
        f.write(f"Total rows read        : {df['rows_read'].sum()}\n")
        f.write(f"Total rows loaded      : {df['rows_loaded'].sum()}\n")
        f.write(f"Total rows rejected    : {df['rows_rejected'].sum()}\n")
        f.write(f"PRAGMA foreign_key_check violations: {len(fk_violations)}\n")


if __name__ == "__main__":
    results = run_full_load()
    for a in results:
        print(f"{a.source_file:30s} -> {a.target_table:15s} read={a.rows_read:5d} loaded={a.rows_loaded:5d} rejected={a.rows_rejected:4d}")
