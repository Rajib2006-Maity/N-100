"""
src/etl/generate_synthetic_data.py

NOTE ON SCOPE:
No real NIFTY100 source files were provided to this project. To make
the rest of Sprint 1 (loader, normaliser, validator, schema, tests)
fully runnable and demonstrable end-to-end, this script generates a
realistic SYNTHETIC dataset of 92 companies across 12 Excel files
(7 core + 5 supplementary), matching the structure the real loader
expects. Swap these files for the real NIFTY100 exports and the rest
of the pipeline (loader.py, validator.py, compute_ratios.py) runs
unchanged.

Deliberately injected data quality issues (a handful of negative sales
rows, a few unbalanced balance sheets, a few companies with <5 years
of history, a malformed URL or two, etc.) exist so that the Day 03
validator and Day 06 manual review have real findings to act on.
"""

from __future__ import annotations

import random
from datetime import date, timedelta
from pathlib import Path

import pandas as pd
from faker import Faker

random.seed(42)
fake = Faker("en_IN")
Faker.seed(42)

RAW_DIR = Path(__file__).resolve().parents[2] / "data" / "raw"

N_COMPANIES = 92

SECTORS = [
    ("IT", "Information Technology"),
    ("BANK", "Banking"),
    ("FIN", "Financial Services"),
    ("FMCG", "FMCG"),
    ("AUTO", "Automobile"),
    ("PHARMA", "Pharmaceuticals"),
    ("ENERGY", "Energy & Power"),
    ("METAL", "Metals & Mining"),
    ("CEMENT", "Cement & Construction"),
    ("TELECOM", "Telecom"),
    ("CONSUMER", "Consumer Durables"),
    ("INFRA", "Infrastructure"),
]

NAME_PREFIXES = [
    "National", "Bharat", "Indus", "Hindustan", "Reliable", "Apex", "Sterling",
    "Crown", "Sunrise", "Pioneer", "Vertex", "Horizon", "United", "Continental",
    "Premier", "Global", "Madras", "Deccan", "Ganga", "Himalaya", "Coastal",
    "Capital", "Allied", "Vega", "Orbit", "Quantum", "Lotus", "Royal", "Shree",
    "Maple", "Silverline", "Trident", "Eastern", "Western", "Northern", "Falcon",
]
NAME_SUFFIXES = [
    "Industries", "Enterprises", "Corp", "Motors", "Pharma", "Bank", "Cements",
    "Power", "Steel", "Textiles", "Foods", "Chemicals", "Infrastructure",
    "Technologies", "Finance", "Telecom", "Logistics", "Energy", "Holdings",
    "Consumer Products",
]


def _money(base, year_idx, growth=0.10, noise=0.06):
    """Simulate a growing-with-noise financial figure across years."""
    val = base * ((1 + growth) ** year_idx)
    val *= 1 + random.uniform(-noise, noise)
    return round(val, 2)


def generate_companies():
    rows = []
    used_names = set()
    used_tickers = set()
    for i in range(1, N_COMPANIES + 1):
        sector_code, _ = random.choice(SECTORS)
        while True:
            name = f"{random.choice(NAME_PREFIXES)} {random.choice(NAME_SUFFIXES)}"
            if name not in used_names:
                used_names.add(name)
                break
        ticker_base = "".join(w[0] for w in name.split()).upper()
        ticker = ticker_base + str(i)
        # occasionally add a stray exchange suffix / lowercase / whitespace
        # to exercise normalize_ticker()
        raw_ticker = ticker
        if i % 17 == 0:
            raw_ticker = f" {ticker.lower()}.ns "
        used_tickers.add(ticker)

        isin = f"INE{random.randint(100,999)}{random.choice('ABCDEFGHJKLMNPQRSTUVWXYZ')}{random.randint(10000,99999)}"
        listing_year = random.randint(1995, 2022)
        listing_date = date(listing_year, random.randint(1, 12), random.randint(1, 28))
        cap_cat = random.choices(["LARGE", "MID", "SMALL"], weights=[0.4, 0.4, 0.2])[0]

        rows.append({
            "company_id_src": i,
            "ticker": raw_ticker,
            "company_name": name,
            "isin": isin,
            "sector_code": sector_code,
            "listing_date": listing_date.isoformat(),
            "market_cap_category": cap_cat,
            # Years of P&L/BS/CF history this company will get (used by
            # the other generators below) — intentionally a handful of
            # newly-listed companies have <5 years of history.
            "_n_years": 3 if i in (5, 19, 33, 58, 77) else random.randint(12, 17),
        })
    return pd.DataFrame(rows)


def generate_sectors():
    return pd.DataFrame(
        [{"sector_code": code, "sector_name": name} for code, name in SECTORS]
    )


def generate_pnl(companies: pd.DataFrame):
    rows = []
    end_year = 2025
    for _, c in companies.iterrows():
        n_years = c["_n_years"]
        base_sales = random.uniform(200, 50000)
        for yi in range(n_years):
            year = end_year - n_years + yi + 1
            sales = _money(base_sales, yi)
            expenses = sales * random.uniform(0.65, 0.88)
            operating_profit = sales - expenses
            opm = round(operating_profit / sales * 100, 2) if sales else None
            other_income = round(sales * random.uniform(0.0, 0.03), 2)
            depreciation = round(sales * random.uniform(0.02, 0.06), 2)
            interest = round(sales * random.uniform(0.0, 0.05), 2)
            pbt = operating_profit + other_income - depreciation - interest
            tax = round(pbt * random.uniform(0.15, 0.34), 2) if pbt > 0 else round(pbt * 0.0, 2)
            net_profit = round(pbt - tax, 2)
            eps = round(net_profit / random.uniform(5, 50), 2)

            # --- inject a few intentional DQ issues ---
            if random.random() < 0.01:
                sales = -abs(sales)  # DQ-06 violation: negative sales
            if random.random() < 0.015:
                eps = abs(eps)  # DQ-11 violation: positive EPS despite loss
                net_profit = -abs(net_profit)
            if random.random() < 0.01:
                # DQ-05 violation: stored OPM doesn't match computed OPM
                opm = round(opm + random.uniform(8, 15), 2)

            rows.append({
                "company_id_src": c["company_id_src"],
                "ticker": c["ticker"],
                "year_label": f"FY{str(year)[-2:]}",
                "sales": round(sales, 2),
                "expenses": round(expenses, 2),
                "operating_profit": round(operating_profit, 2),
                "opm_percent": opm,
                "other_income": other_income,
                "depreciation": depreciation,
                "interest": interest,
                "profit_before_tax": round(pbt, 2),
                "tax": tax,
                "net_profit": net_profit,
                "eps": eps,
            })
    return pd.DataFrame(rows)


def generate_balance_sheet(companies: pd.DataFrame):
    rows = []
    end_year = 2025
    for _, c in companies.iterrows():
        # balance sheet history sometimes runs 0-2 years longer than P&L
        n_years = c["_n_years"] + random.choice([0, 0, 1, 1, 2])
        base_assets = random.uniform(500, 80000)
        for yi in range(n_years):
            year = end_year - n_years + yi + 1
            total_assets = _money(base_assets, yi)
            equity_capital = round(total_assets * random.uniform(0.01, 0.05), 2)
            reserves = round(total_assets * random.uniform(0.25, 0.55), 2)
            borrowings = round(total_assets * random.uniform(0.1, 0.4), 2)
            other_liabilities = round(
                total_assets - equity_capital - reserves - borrowings, 2
            )
            total_liabilities = round(
                equity_capital + reserves + borrowings + other_liabilities, 2
            )
            fixed_assets = round(total_assets * random.uniform(0.3, 0.6), 2)
            cwip = round(total_assets * random.uniform(0.0, 0.05), 2)
            investments = round(total_assets * random.uniform(0.05, 0.2), 2)
            other_assets = round(
                total_assets - fixed_assets - cwip - investments, 2
            )

            # --- inject a few intentional DQ issues: assets/liabilities
            # mismatch (a genuine reporting discrepancy worth flagging via
            # the WARNING-level DQ-04 rule). other_liabilities is recomputed
            # so the statement's own component arithmetic stays internally
            # consistent and DQ-12 (CRITICAL) does not fire. ---
            if random.random() < 0.02:
                total_liabilities = round(total_liabilities * random.uniform(1.05, 1.2), 2)
                other_liabilities = round(
                    total_liabilities - equity_capital - reserves - borrowings, 2
                )

            rows.append({
                "company_id_src": c["company_id_src"],
                "ticker": c["ticker"],
                "year_label": f"FY{str(year)[-2:]}",
                "equity_capital": equity_capital,
                "reserves": reserves,
                "borrowings": borrowings,
                "other_liabilities": other_liabilities,
                "total_liabilities": total_liabilities,
                "fixed_assets": fixed_assets,
                "cwip": cwip,
                "investments": investments,
                "other_assets": other_assets,
                "total_assets": round(total_assets, 2),
            })
    return pd.DataFrame(rows)


def generate_cash_flow(companies: pd.DataFrame):
    rows = []
    end_year = 2025
    for _, c in companies.iterrows():
        # cash flow history sometimes shorter than P&L (older filings missing)
        n_years = max(3, c["_n_years"] - random.choice([0, 0, 1, 1, 2]))
        base = random.uniform(100, 20000)
        for yi in range(n_years):
            year = end_year - n_years + yi + 1
            cfo = _money(base, yi, growth=0.08)
            cfi = -round(abs(cfo) * random.uniform(0.2, 0.6), 2)
            cff = -round(abs(cfo) * random.uniform(0.1, 0.5), 2)
            net_cash = round(cfo + cfi + cff, 2)

            # NOTE: net cash flow must always reconcile to cfo+cfi+cff in the
            # final clean dataset (DQ-07 is a CRITICAL rule) — no corruption
            # injected here.

            rows.append({
                "company_id_src": c["company_id_src"],
                "ticker": c["ticker"],
                "year_label": f"FY{str(year)[-2:]}",
                "cash_from_operating": round(cfo, 2),
                "cash_from_investing": cfi,
                "cash_from_financing": cff,
                "net_cash_flow": net_cash,
            })
    return pd.DataFrame(rows)


def generate_stock_prices(companies: pd.DataFrame):
    """60 monthly closing-price records per company (5 years) -> 92*60 = 5520 rows."""
    rows = []
    start = date(2021, 1, 1)
    for _, c in companies.iterrows():
        price = random.uniform(50, 4000)
        d = start
        for _ in range(60):
            change = random.uniform(-0.08, 0.09)
            o = price
            price = max(1.0, price * (1 + change))
            high = max(o, price) * random.uniform(1.0, 1.03)
            low = min(o, price) * random.uniform(0.97, 1.0)
            vol = random.randint(10_000, 5_000_000)
            rows.append({
                "company_id_src": c["company_id_src"],
                "ticker": c["ticker"],
                "price_date": d.isoformat(),
                "open": round(o, 2),
                "high": round(high, 2),
                "low": round(low, 2),
                "close": round(price, 2),
                "volume": vol,
            })
            # advance by ~1 month
            d = d + timedelta(days=30)
    return pd.DataFrame(rows)


def generate_shareholding_pattern(companies: pd.DataFrame):
    rows = []
    for _, c in companies.iterrows():
        promoter = random.uniform(30, 75)
        fii = random.uniform(5, 30)
        dii = random.uniform(5, 25)
        public = max(0.0, 100 - promoter - fii - dii)
        rows.append({
            "company_id_src": c["company_id_src"],
            "ticker": c["ticker"],
            "as_of_date": date(2025, 12, 31).isoformat(),
            "promoter_holding_pct": round(promoter, 2),
            "fii_holding_pct": round(fii, 2),
            "dii_holding_pct": round(dii, 2),
            "public_holding_pct": round(public, 2),
        })
    return pd.DataFrame(rows)


def generate_analysis_notes(companies: pd.DataFrame):
    notes = [
        "Strong free cash flow generation over the last 3 years.",
        "Margins under pressure from rising input costs.",
        "Management has guided for double-digit revenue growth.",
        "Debt reduction remains a key priority for FY26.",
        "Recent capacity expansion expected to drive volume growth.",
        "Working capital cycle has lengthened over the past 2 years.",
    ]
    rows = []
    for _, c in companies.iterrows():
        rows.append({
            "company_id_src": c["company_id_src"],
            "ticker": c["ticker"],
            "note": random.choice(notes),
            "as_of_date": date(2026, 1, 15).isoformat(),
        })
    return pd.DataFrame(rows)


def generate_corporate_actions(companies: pd.DataFrame):
    actions = ["Final Dividend", "Interim Dividend", "Bonus 1:1", "Stock Split 1:2", "Buyback"]
    rows = []
    for _, c in companies.iterrows():
        for _ in range(random.randint(1, 3)):
            rows.append({
                "company_id_src": c["company_id_src"],
                "ticker": c["ticker"],
                "action_type": random.choice(actions),
                "action_value": f"{random.uniform(1, 25):.2f}%" if "Dividend" in actions[0] else "NA",
                "ex_date": fake.date_between(date(2021, 1, 1), date(2025, 12, 31)).isoformat(),
            })
    return pd.DataFrame(rows)


def generate_documents(companies: pd.DataFrame):
    rows = []
    for _, c in companies.iterrows():
        domain = "https://www.example-investor-relations.com"
        for doc_type in ("Annual Report", "Investor Presentation"):
            url = f"{domain}/{c['ticker'].strip().upper().replace(' ', '')}/{doc_type.replace(' ', '_')}.pdf"
            # inject a few malformed URLs to exercise DQ-10
            if random.random() < 0.03:
                url = url.replace("https://", "")
            rows.append({
                "company_id_src": c["company_id_src"],
                "ticker": c["ticker"],
                "doc_type": doc_type,
                "doc_url": url,
                "doc_date": date(2025, 6, 30).isoformat(),
            })
    return pd.DataFrame(rows)


def generate_pros_and_cons(companies: pd.DataFrame):
    pros = [
        "Company has reduced debt significantly.",
        "Company has delivered good profit growth.",
        "Company has a healthy dividend payout.",
        "Company has a strong return on equity.",
    ]
    cons = [
        "Company has low interest coverage ratio.",
        "Company has a declining net cash flow.",
        "Promoter holding has decreased over the past quarters.",
        "Working capital requirements have increased.",
    ]
    rows = []
    for _, c in companies.iterrows():
        for p in random.sample(pros, k=random.randint(1, 2)):
            rows.append({"company_id_src": c["company_id_src"], "ticker": c["ticker"], "type": "PRO", "description": p})
        for cdesc in random.sample(cons, k=random.randint(1, 2)):
            rows.append({"company_id_src": c["company_id_src"], "ticker": c["ticker"], "type": "CON", "description": cdesc})
    return pd.DataFrame(rows)


def generate_peer_groups(companies: pd.DataFrame):
    rows = []
    by_sector = companies.groupby("sector_code")
    for sector_code, group in by_sector:
        tickers = list(group["company_id_src"])
        for cid in tickers:
            peers = [p for p in tickers if p != cid]
            for peer in random.sample(peers, k=min(3, len(peers))):
                rows.append({
                    "company_id_src": cid,
                    "peer_company_id_src": peer,
                    "sector_code": sector_code,
                })
    return pd.DataFrame(rows)


def main():
    RAW_DIR.mkdir(parents=True, exist_ok=True)
    companies = generate_companies()

    # ---- 7 CORE files ----
    companies.drop(columns=["_n_years"]).to_excel(RAW_DIR / "companies_master.xlsx", index=False)
    generate_sectors().to_excel(RAW_DIR / "sectors.xlsx", index=False)
    generate_pnl(companies).to_excel(RAW_DIR / "profit_and_loss.xlsx", index=False)
    generate_balance_sheet(companies).to_excel(RAW_DIR / "balance_sheet.xlsx", index=False)
    generate_cash_flow(companies).to_excel(RAW_DIR / "cash_flow.xlsx", index=False)
    generate_stock_prices(companies).to_excel(RAW_DIR / "stock_prices.xlsx", index=False)
    generate_shareholding_pattern(companies).to_excel(RAW_DIR / "shareholding_pattern.xlsx", index=False)

    # ---- 5 SUPPLEMENTARY files ----
    generate_analysis_notes(companies).to_excel(RAW_DIR / "analysis_notes.xlsx", index=False)
    generate_corporate_actions(companies).to_excel(RAW_DIR / "corporate_actions.xlsx", index=False)
    generate_documents(companies).to_excel(RAW_DIR / "company_documents.xlsx", index=False)
    generate_pros_and_cons(companies).to_excel(RAW_DIR / "pros_and_cons.xlsx", index=False)
    generate_peer_groups(companies).to_excel(RAW_DIR / "peer_groups.xlsx", index=False)

    print(f"Generated 12 synthetic source files in {RAW_DIR}")
    print(f"companies={len(companies)}")


if __name__ == "__main__":
    main()
