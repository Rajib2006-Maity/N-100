"""
src/etl/validator.py
Sprint 1 · Day 03 — Schema Validator: 16 Data Quality Rules (DQ-01..DQ-16)

Each rule is implemented as a standalone function that takes a sqlite3
connection and returns a list of violation dicts:
    {rule_id, severity, table, company_id, year, field, message}

Severity is either "CRITICAL" or "WARNING":
  - CRITICAL: PK uniqueness, composite (company_id, year) uniqueness,
    FK integrity, net-cash reconciliation, year range, ticker format,
    mandatory non-null fields, balance-sheet component balance.
  - WARNING: BS total balance tolerance, OPM cross-check, positive
    sales, tax rate sanity, dividend cap, URL format, EPS sign
    consistency, year coverage (<5 years).

run_all() executes every rule and writes output/validation_failures.csv.
Per the sprint exit criteria, any CRITICAL failures must be resolved
before Day 05's full load is considered complete.
"""

from __future__ import annotations

import os
import re
import sqlite3
from pathlib import Path

import pandas as pd
from dotenv import load_dotenv

load_dotenv()

PROJECT_ROOT = Path(__file__).resolve().parents[2]
DB_PATH = PROJECT_ROOT / os.getenv("DB_PATH", "nifty100.db")
OUTPUT_DIR = PROJECT_ROOT / os.getenv("OUTPUT_DIR", "output")

BS_BALANCE_TOLERANCE = float(os.getenv("BS_BALANCE_TOLERANCE", "0.01"))
OPM_TOLERANCE = float(os.getenv("OPM_TOLERANCE", "0.02"))
NET_CASH_TOLERANCE = float(os.getenv("NET_CASH_TOLERANCE", "0.01"))
MIN_YEAR_COVERAGE = int(os.getenv("MIN_YEAR_COVERAGE", "5"))

CRITICAL = "CRITICAL"
WARNING = "WARNING"

_TICKER_RE = re.compile(r"^[A-Z0-9&\-]{1,20}$")
_URL_RE = re.compile(r"^https?://[^\s]+$", re.IGNORECASE)
MIN_VALID_YEAR = 1990
MAX_VALID_YEAR = 2027


def _v(rule_id, severity, table, message, company_id=None, year=None, field=None):
    return {
        "rule_id": rule_id,
        "severity": severity,
        "table": table,
        "company_id": company_id,
        "year": year,
        "field": field,
        "message": message,
    }


# ---------------------------------------------------------------------
# DQ-01 — PK uniqueness on every single-column-PK table
# ---------------------------------------------------------------------
def dq01_pk_uniqueness(conn) -> list[dict]:
    violations = []
    pk_map = {
        "companies": "company_id",
        "sectors": "sector_id",
        "profitandloss": "pl_id",
        "balancesheet": "bs_id",
        "cashflow": "cf_id",
        "stock_prices": "price_id",
        "financial_ratios": "ratio_id",
        "analysis": "analysis_id",
        "documents": "doc_id",
        "prosandcons": "pac_id",
        "peer_groups": "peer_id",
    }
    for table, pk in pk_map.items():
        rows = conn.execute(
            f"SELECT {pk}, COUNT(*) c FROM {table} GROUP BY {pk} HAVING c > 1"
        ).fetchall()
        for pk_val, cnt in rows:
            violations.append(_v("DQ-01", CRITICAL, table,
                                  f"duplicate primary key {pk}={pk_val} ({cnt} rows)"))
    return violations


# ---------------------------------------------------------------------
# DQ-02 — composite (company_id, year) uniqueness on yearly tables
# ---------------------------------------------------------------------
def dq02_composite_year_pk(conn) -> list[dict]:
    violations = []
    for table in ("profitandloss", "balancesheet", "cashflow", "financial_ratios"):
        rows = conn.execute(
            f"SELECT company_id, year, COUNT(*) c FROM {table} GROUP BY company_id, year HAVING c > 1"
        ).fetchall()
        for cid, year, cnt in rows:
            violations.append(_v("DQ-02", CRITICAL, table,
                                  f"duplicate (company_id, year) ({cnt} rows)", cid, year))
    return violations


# ---------------------------------------------------------------------
# DQ-03 — FK referential integrity (delegates to SQLite's own checker)
# ---------------------------------------------------------------------
def dq03_fk_integrity(conn) -> list[dict]:
    violations = []
    rows = conn.execute("PRAGMA foreign_key_check;").fetchall()
    for table, rowid, parent, fkid in rows:
        violations.append(_v("DQ-03", CRITICAL, table,
                              f"FK violation referencing {parent} (rowid={rowid}, fk index={fkid})"))
    return violations


# ---------------------------------------------------------------------
# DQ-04 — balance sheet TOTAL balance within tolerance (WARNING)
# ---------------------------------------------------------------------
def dq04_bs_balance(conn) -> list[dict]:
    violations = []
    rows = conn.execute(
        "SELECT company_id, year, total_assets, total_liabilities FROM balancesheet"
    ).fetchall()
    for cid, year, assets, liabilities in rows:
        if assets is None or liabilities is None or assets == 0:
            continue
        diff_pct = abs(assets - liabilities) / abs(assets)
        if diff_pct >= BS_BALANCE_TOLERANCE:
            violations.append(_v("DQ-04", WARNING, "balancesheet",
                                  f"assets/liabilities mismatch {diff_pct:.2%} (tolerance {BS_BALANCE_TOLERANCE:.0%})",
                                  cid, year, "total_assets/total_liabilities"))
    return violations


# ---------------------------------------------------------------------
# DQ-05 — OPM cross-check: stored opm_percent vs computed (WARNING)
# ---------------------------------------------------------------------
def dq05_opm_crosscheck(conn) -> list[dict]:
    violations = []
    rows = conn.execute(
        "SELECT company_id, year, sales, operating_profit, opm_percent FROM profitandloss"
    ).fetchall()
    for cid, year, sales, op, opm in rows:
        if sales in (None, 0) or op is None or opm is None:
            continue
        computed = op / sales * 100
        if abs(computed - opm) >= OPM_TOLERANCE * 100:
            violations.append(_v("DQ-05", WARNING, "profitandloss",
                                  f"stored OPM {opm:.2f}% vs computed {computed:.2f}%",
                                  cid, year, "opm_percent"))
    return violations


# ---------------------------------------------------------------------
# DQ-06 — positive sales (WARNING per sprint spec grouping)
# ---------------------------------------------------------------------
def dq06_positive_sales(conn) -> list[dict]:
    violations = []
    rows = conn.execute(
        "SELECT company_id, year, sales FROM profitandloss WHERE sales IS NOT NULL AND sales <= 0"
    ).fetchall()
    for cid, year, sales in rows:
        violations.append(_v("DQ-06", WARNING, "profitandloss",
                              f"non-positive sales value: {sales}", cid, year, "sales"))
    return violations


# ---------------------------------------------------------------------
# DQ-07 — net cash flow reconciliation (CRITICAL)
# ---------------------------------------------------------------------
def dq07_net_cash_reconciliation(conn) -> list[dict]:
    violations = []
    rows = conn.execute(
        "SELECT company_id, year, cash_from_operating, cash_from_investing, cash_from_financing, net_cash_flow FROM cashflow"
    ).fetchall()
    for cid, year, cfo, cfi, cff, net in rows:
        if None in (cfo, cfi, cff, net):
            continue
        expected = cfo + cfi + cff
        denom = max(abs(expected), 1.0)
        if abs(expected - net) / denom >= NET_CASH_TOLERANCE:
            violations.append(_v("DQ-07", CRITICAL, "cashflow",
                                  f"net_cash_flow {net} != cfo+cfi+cff {expected:.2f}",
                                  cid, year, "net_cash_flow"))
    return violations


# ---------------------------------------------------------------------
# DQ-08 — tax rate sanity (0% - 60% of PBT) (WARNING)
# ---------------------------------------------------------------------
def dq08_tax_rate_sanity(conn) -> list[dict]:
    violations = []
    rows = conn.execute(
        "SELECT company_id, year, profit_before_tax, tax FROM profitandloss"
    ).fetchall()
    for cid, year, pbt, tax in rows:
        if pbt is None or tax is None or pbt <= 0:
            continue
        rate = tax / pbt
        if rate < 0 or rate > 0.60:
            violations.append(_v("DQ-08", WARNING, "profitandloss",
                                  f"implied tax rate {rate:.1%} outside [0%, 60%]",
                                  cid, year, "tax"))
    return violations


# ---------------------------------------------------------------------
# DQ-09 — dividend cap: analysis metric dividend value <= 25% (WARNING)
# ---------------------------------------------------------------------
def dq09_dividend_cap(conn) -> list[dict]:
    violations = []
    rows = conn.execute(
        "SELECT analysis_id, company_id, metric_name, metric_value FROM analysis WHERE metric_name LIKE 'corporate_action:%Dividend%'"
    ).fetchall()
    for aid, cid, metric_name, metric_value in rows:
        try:
            pct = float(str(metric_value).replace("%", ""))
        except (ValueError, TypeError):
            continue
        if pct > 25.0:
            violations.append(_v("DQ-09", WARNING, "analysis",
                                  f"dividend value {pct}% exceeds 25% sanity cap",
                                  cid, None, "metric_value"))
    return violations


# ---------------------------------------------------------------------
# DQ-10 — document URL format validity (WARNING)
# ---------------------------------------------------------------------
def dq10_url_format(conn) -> list[dict]:
    violations = []
    rows = conn.execute("SELECT doc_id, company_id, doc_url FROM documents").fetchall()
    for doc_id, cid, url in rows:
        if not url or not _URL_RE.match(url):
            violations.append(_v("DQ-10", WARNING, "documents",
                                  f"malformed URL: {url!r}", cid, None, "doc_url"))
    return violations


# ---------------------------------------------------------------------
# DQ-11 — EPS sign consistency with net profit (WARNING)
# ---------------------------------------------------------------------
def dq11_eps_sign(conn) -> list[dict]:
    violations = []
    rows = conn.execute(
        "SELECT company_id, year, net_profit, eps FROM profitandloss"
    ).fetchall()
    for cid, year, net_profit, eps in rows:
        if net_profit is None or eps is None:
            continue
        if (net_profit < 0 and eps > 0) or (net_profit > 0 and eps < 0):
            violations.append(_v("DQ-11", WARNING, "profitandloss",
                                  f"EPS sign ({eps}) inconsistent with net_profit ({net_profit})",
                                  cid, year, "eps"))
    return violations


# ---------------------------------------------------------------------
# DQ-12 — balance sheet COMPONENT balance: liability components sum to
# total_liabilities (CRITICAL — internal arithmetic of the statement
# itself, distinct from DQ-04's assets-vs-liabilities cross-check)
# ---------------------------------------------------------------------
def dq12_bs_component_balance(conn) -> list[dict]:
    violations = []
    rows = conn.execute(
        """SELECT company_id, year, equity_capital, reserves, borrowings,
                  other_liabilities, total_liabilities FROM balancesheet"""
    ).fetchall()
    for cid, year, eq, res, borrow, other, total in rows:
        if None in (eq, res, borrow, other, total):
            continue
        expected = eq + res + borrow + other
        denom = max(abs(expected), 1.0)
        if abs(expected - total) / denom >= BS_BALANCE_TOLERANCE:
            violations.append(_v("DQ-12", CRITICAL, "balancesheet",
                                  f"liability components sum {expected:.2f} != total_liabilities {total}",
                                  cid, year, "total_liabilities"))
    return violations


# ---------------------------------------------------------------------
# DQ-13 — year range validity (CRITICAL)
# ---------------------------------------------------------------------
def dq13_year_range(conn) -> list[dict]:
    violations = []
    for table in ("profitandloss", "balancesheet", "cashflow"):
        rows = conn.execute(f"SELECT company_id, year FROM {table}").fetchall()
        for cid, year in rows:
            if year is None or year < MIN_VALID_YEAR or year > MAX_VALID_YEAR:
                violations.append(_v("DQ-13", CRITICAL, table,
                                      f"year {year} outside valid range [{MIN_VALID_YEAR}, {MAX_VALID_YEAR}]",
                                      cid, year, "year"))
    return violations


# ---------------------------------------------------------------------
# DQ-14 — ticker format validity (CRITICAL)
# ---------------------------------------------------------------------
def dq14_ticker_format(conn) -> list[dict]:
    violations = []
    rows = conn.execute("SELECT company_id, ticker FROM companies").fetchall()
    for cid, ticker in rows:
        if not ticker or not _TICKER_RE.match(ticker):
            violations.append(_v("DQ-14", CRITICAL, "companies",
                                  f"ticker fails format validation: {ticker!r}", cid, None, "ticker"))
    return violations


# ---------------------------------------------------------------------
# DQ-15 — mandatory non-null fields (CRITICAL)
# ---------------------------------------------------------------------
def dq15_mandatory_fields(conn) -> list[dict]:
    violations = []
    checks = [
        ("companies", "company_id, ticker, company_name", "company_name IS NULL OR ticker IS NULL"),
        ("profitandloss", "company_id, year", "sales IS NULL"),
        ("balancesheet", "company_id, year", "total_assets IS NULL"),
        ("cashflow", "company_id, year", "net_cash_flow IS NULL"),
    ]
    for table, _cols, where in checks:
        rows = conn.execute(f"SELECT company_id FROM {table} WHERE {where}").fetchall()
        for (cid,) in rows:
            violations.append(_v("DQ-15", CRITICAL, table,
                                  f"mandatory field is NULL ({where})", cid))
    return violations


# ---------------------------------------------------------------------
# DQ-16 — year coverage: company should have >= MIN_YEAR_COVERAGE years
# of P&L history (WARNING — flags newly-listed / sparse-history companies
# for the Day 06 manual review)
# ---------------------------------------------------------------------
def dq16_year_coverage(conn) -> list[dict]:
    violations = []
    rows = conn.execute(
        "SELECT company_id, COUNT(*) n FROM profitandloss GROUP BY company_id HAVING n < ?",
        (MIN_YEAR_COVERAGE,),
    ).fetchall()
    for cid, n in rows:
        violations.append(_v("DQ-16", WARNING, "profitandloss",
                              f"only {n} year(s) of P&L history (< {MIN_YEAR_COVERAGE} minimum)", cid))
    return violations


RULES = [
    ("DQ-01", dq01_pk_uniqueness),
    ("DQ-02", dq02_composite_year_pk),
    ("DQ-03", dq03_fk_integrity),
    ("DQ-04", dq04_bs_balance),
    ("DQ-05", dq05_opm_crosscheck),
    ("DQ-06", dq06_positive_sales),
    ("DQ-07", dq07_net_cash_reconciliation),
    ("DQ-08", dq08_tax_rate_sanity),
    ("DQ-09", dq09_dividend_cap),
    ("DQ-10", dq10_url_format),
    ("DQ-11", dq11_eps_sign),
    ("DQ-12", dq12_bs_component_balance),
    ("DQ-13", dq13_year_range),
    ("DQ-14", dq14_ticker_format),
    ("DQ-15", dq15_mandatory_fields),
    ("DQ-16", dq16_year_coverage),
]


def run_all(db_path: Path = DB_PATH) -> pd.DataFrame:
    conn = sqlite3.connect(db_path)
    conn.execute("PRAGMA foreign_keys = ON;")
    all_violations = []
    for rule_id, fn in RULES:
        all_violations.extend(fn(conn))
    conn.close()

    df = pd.DataFrame(all_violations, columns=["rule_id", "severity", "table", "company_id", "year", "field", "message"])
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    df.to_csv(OUTPUT_DIR / "validation_failures.csv", index=False)
    return df


def summarize(df: pd.DataFrame) -> str:
    lines = [f"Total violations: {len(df)}"]
    if len(df):
        lines.append(df.groupby(["rule_id", "severity"]).size().to_string())
        n_critical = (df["severity"] == "CRITICAL").sum()
        lines.append(f"\nCRITICAL count: {n_critical}")
    return "\n".join(lines)


if __name__ == "__main__":
    result = run_all()
    print(summarize(result))
