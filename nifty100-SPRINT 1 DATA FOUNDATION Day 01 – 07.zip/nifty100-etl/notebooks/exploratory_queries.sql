-- =====================================================================
-- notebooks/exploratory_queries.sql
-- Sprint 1 · Day 06/07 — Exploratory SQL queries against nifty100.db
--
-- Run with: sqlite3 nifty100.db < notebooks/exploratory_queries.sql
-- or paste individual queries into any SQLite client / DB Browser.
-- =====================================================================


-- ---------------------------------------------------------------------
-- Query 1: Company roster with sector — quick sanity check of the
-- companies table and its join to sectors.
-- ---------------------------------------------------------------------
SELECT
    c.company_id,
    c.ticker,
    c.company_name,
    s.sector_name,
    c.market_cap_category
FROM companies c
JOIN sectors s ON c.sector_id = s.sector_id
ORDER BY s.sector_name, c.company_name
LIMIT 20;


-- ---------------------------------------------------------------------
-- Query 2: Sector composition — how many companies per sector, useful
-- for spotting sector concentration/imbalance in the universe.
-- ---------------------------------------------------------------------
SELECT
    s.sector_name,
    COUNT(c.company_id) AS num_companies
FROM sectors s
LEFT JOIN companies c ON c.sector_id = s.sector_id
GROUP BY s.sector_name
ORDER BY num_companies DESC;


-- ---------------------------------------------------------------------
-- Query 3: Latest-year revenue leaders — top 10 companies by sales in
-- the most recent year each company reported.
-- ---------------------------------------------------------------------
WITH latest_year AS (
    SELECT company_id, MAX(year) AS yr
    FROM profitandloss
    GROUP BY company_id
)
SELECT
    c.company_name,
    pl.year,
    pl.sales,
    pl.net_profit
FROM profitandloss pl
JOIN latest_year ly ON pl.company_id = ly.company_id AND pl.year = ly.yr
JOIN companies c ON c.company_id = pl.company_id
ORDER BY pl.sales DESC
LIMIT 10;


-- ---------------------------------------------------------------------
-- Query 4: Multi-year revenue CAGR per company (first vs last reported
-- year), useful for a quick growth screen.
-- ---------------------------------------------------------------------
WITH bounds AS (
    SELECT
        company_id,
        MIN(year) AS first_year,
        MAX(year) AS last_year
    FROM profitandloss
    GROUP BY company_id
    HAVING COUNT(*) >= 2
)
SELECT
    c.company_name,
    b.first_year,
    p1.sales AS first_year_sales,
    b.last_year,
    p2.sales AS last_year_sales,
    ROUND(
        (POWER(p2.sales / p1.sales, 1.0 / (b.last_year - b.first_year)) - 1) * 100, 2
    ) AS cagr_percent
FROM bounds b
JOIN companies c ON c.company_id = b.company_id
JOIN profitandloss p1 ON p1.company_id = b.company_id AND p1.year = b.first_year
JOIN profitandloss p2 ON p2.company_id = b.company_id AND p2.year = b.last_year
WHERE p1.sales > 0
ORDER BY cagr_percent DESC
LIMIT 15;


-- ---------------------------------------------------------------------
-- Query 5: Latest-year financial ratios snapshot — ROE, ROCE,
-- debt-to-equity, current ratio for each company's most recent year.
-- ---------------------------------------------------------------------
WITH latest_year AS (
    SELECT company_id, MAX(year) AS yr
    FROM financial_ratios
    GROUP BY company_id
)
SELECT
    c.company_name,
    fr.year,
    fr.roce_percent,
    fr.roe_percent,
    fr.debt_to_equity,
    fr.current_ratio
FROM financial_ratios fr
JOIN latest_year ly ON fr.company_id = ly.company_id AND fr.year = ly.yr
JOIN companies c ON c.company_id = fr.company_id
ORDER BY fr.roe_percent DESC
LIMIT 15;


-- ---------------------------------------------------------------------
-- Query 6: Stock price summary — average close, min/max close, and
-- trading-day count per company (sanity check on stock_prices volume).
-- ---------------------------------------------------------------------
SELECT
    c.company_name,
    COUNT(sp.price_id) AS trading_days,
    ROUND(AVG(sp.close), 2) AS avg_close,
    ROUND(MIN(sp.close), 2) AS min_close,
    ROUND(MAX(sp.close), 2) AS max_close
FROM stock_prices sp
JOIN companies c ON c.company_id = sp.company_id
GROUP BY c.company_id
ORDER BY avg_close DESC
LIMIT 15;


-- ---------------------------------------------------------------------
-- Query 7: Pros and cons tally per company — counts of PRO vs CON
-- entries, a quick qualitative-sentiment proxy.
-- ---------------------------------------------------------------------
SELECT
    c.company_name,
    SUM(CASE WHEN pac.type = 'PRO' THEN 1 ELSE 0 END) AS num_pros,
    SUM(CASE WHEN pac.type = 'CON' THEN 1 ELSE 0 END) AS num_cons
FROM prosandcons pac
JOIN companies c ON c.company_id = pac.company_id
GROUP BY c.company_id
ORDER BY num_cons DESC, num_pros ASC
LIMIT 15;


-- ---------------------------------------------------------------------
-- Query 8: Peer group explorer — for a given company, list its
-- declared peers within the same sector. (Replace company_id = 1 with
-- any company of interest.)
-- ---------------------------------------------------------------------
SELECT
    c1.company_name AS company,
    c2.company_name AS peer,
    s.sector_name
FROM peer_groups pg
JOIN companies c1 ON c1.company_id = pg.company_id
JOIN companies c2 ON c2.company_id = pg.peer_company_id
JOIN sectors s ON s.sector_id = pg.sector_id
WHERE pg.company_id = 1
ORDER BY peer;


-- ---------------------------------------------------------------------
-- Query 9: Document coverage audit — companies with the fewest
-- documents on file (potential gaps for Day 06 manual review).
-- ---------------------------------------------------------------------
SELECT
    c.company_name,
    COUNT(d.doc_id) AS num_documents
FROM companies c
LEFT JOIN documents d ON d.company_id = c.company_id
GROUP BY c.company_id
ORDER BY num_documents ASC
LIMIT 15;


-- ---------------------------------------------------------------------
-- Query 10: Companies flagged by DQ-16 (sparse year coverage, < 5
-- years of P&L history) — direct candidates for the Day 06 manual
-- review, cross-referenced with their actual ticker/name.
-- ---------------------------------------------------------------------
SELECT
    c.company_id,
    c.ticker,
    c.company_name,
    COUNT(pl.pl_id) AS years_of_pl_history
FROM companies c
JOIN profitandloss pl ON pl.company_id = c.company_id
GROUP BY c.company_id
HAVING years_of_pl_history < 5
ORDER BY years_of_pl_history ASC;
