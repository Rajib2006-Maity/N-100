# Day 06 — Manual Review of Flagged Companies

**Sprint:** Sprint 1 "Data Foundation"
**Reviewer step:** Day 06 manual review (Sprint exit criterion)
**Scope:** 5 companies, selected via DQ-16 (year coverage < 5 years)

## Why these 5 companies

Rather than picking 5 companies at random, this review targets the
companies the validator itself flagged as needing a human look:
`DQ-16` (WARNING) fires whenever a company has fewer than
`MIN_YEAR_COVERAGE` (5) years of profit & loss history. Query 10 in
`notebooks/exploratory_queries.sql` reproduces this list directly from
the database. As of the current load, exactly 5 companies are flagged
— a coincidental but convenient match with the sprint's "review 5
companies" exit criterion.

| company_id | ticker | company_name | sector | years of P&L history |
|---|---|---|---|---|
| 5 | ACP5 | Allied Consumer Products | Pharmaceuticals | 3 |
| 19 | WCP19 | Western Consumer Products | Automobile | 3 |
| 33 | HF33 | Himalaya Finance | Consumer Durables | 3 |
| 58 | ET58 | Eastern Technologies | Infrastructure | 3 |
| 77 | NL77 | National Logistics | Cement & Construction | 3 |

## Findings per company

**ACP5 — Allied Consumer Products.** Three years on file (2023–2025),
sales growing steadily (₹26,550m → ₹29,831m) but net profit dipped in
2024 before partially recovering in 2025. No FK, PK, or arithmetic
violations on this company's rows. The short history looks like a
genuine data-availability gap in the source file rather than a load
defect — recommend backfilling pre-2023 P&L from the company's annual
reports when real source data is substituted in.

**WCP19 — Western Consumer Products.** Three years on file, revenue
and profit both trending up (net profit nearly doubled from 2023 to
2025). Numbers are internally consistent (BS components and net cash
flow both reconcile for this company). Flagged purely for short
history, not for any quality defect.

**HF33 — Himalaya Finance.** Three years on file; despite rising sales,
net profit is gently declining (₹6,778m → ₹4,189m), consistent with
margin compression rather than a data error — no DQ-04/05/07/12
violations recorded against this company. Worth a follow-up with the
finance team on margin trend once full history is available.

**ET58 — Eastern Technologies.** Three years on file with steady
double-digit-percentage sales growth and a slowly improving bottom
line. Clean on all CRITICAL checks. Listing date in the companies
table predates the available P&L history by over two decades, which
confirms the gap is a *source data* completeness issue, not a
listing-recency artifact.

**NL77 — National Logistics.** Three years on file; net profit more
than tripled (₹2,546m → ₹8,515m) on more moderate revenue growth —
the largest profit swing of the five. Worth a sanity call to the
sourced filings to confirm this isn't a one-off (e.g., an asset sale
or tax credit) before this ratio feeds into any peer comparison.

## Conclusion

None of the 5 flagged companies show CRITICAL-level data defects —
their PK/FK integrity, balance-sheet arithmetic, and cash-flow
reconciliation all pass. The common thread is simply fewer years of
P&L history than the 5-year minimum the validator expects. Two
follow-ups for Sprint 2: (1) backfill or source additional historical
years for these 5 tickers where available, and (2) keep `DQ-16` as a
WARNING (not CRITICAL) since a short but internally consistent history
is a coverage gap, not a correctness defect.

*Note: this project currently runs on synthetic demo data (see
`src/etl/generate_synthetic_data.py`); once real NIFTY100 source files
are dropped into `data/raw/`, re-run this review against the actual
flagged companies, as the specific tickers may differ.*
