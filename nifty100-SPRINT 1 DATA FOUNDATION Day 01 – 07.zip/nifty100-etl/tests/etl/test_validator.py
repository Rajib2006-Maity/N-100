"""
tests/etl/test_validator.py
Sprint 1 · Day 03 — unit tests for src/etl/validator.py (DQ-01 .. DQ-16)

Each test builds a tiny in-memory SQLite database from db/schema.sql,
seeds one "clean" company (should produce zero violations for the rule
under test) and, where useful, one "dirty" company/row that deliberately
breaks the rule, then asserts the corresponding dq_xx_*() function
returns the expected violations with the correct rule_id and severity.

A fresh in-memory connection is built per test (function-scoped fixture)
so tests are fully isolated from each other and from the real
nifty100.db.
"""

from __future__ import annotations

import sqlite3
from pathlib import Path

import pytest

from src.etl import validator

SCHEMA_PATH = Path(__file__).resolve().parents[2] / "db" / "schema.sql"


@pytest.fixture
def db():
    """Fresh in-memory SQLite db with schema applied and FK enforcement on."""
    conn = sqlite3.connect(":memory:")
    conn.execute("PRAGMA foreign_keys = ON;")
    conn.executescript(SCHEMA_PATH.read_text())
    conn.commit()
    yield conn
    conn.close()


def _seed_sector_and_companies(conn, n=2):
    conn.execute("INSERT INTO sectors (sector_code, sector_name) VALUES ('IT', 'Information Technology')")
    sector_id = conn.execute("SELECT sector_id FROM sectors").fetchone()[0]
    ids = []
    for i in range(n):
        conn.execute(
            "INSERT INTO companies (ticker, company_name, sector_id) VALUES (?, ?, ?)",
            (f"TICK{i}", f"Company {i}", sector_id),
        )
        ids.append(conn.execute("SELECT last_insert_rowid()").fetchone()[0])
    conn.commit()
    return ids


# ---------------------------------------------------------------------
# DQ-01 — PK uniqueness
# ---------------------------------------------------------------------

def test_dq01_no_violation_on_clean_data(db):
    _seed_sector_and_companies(db, n=2)
    assert validator.dq01_pk_uniqueness(db) == []


def test_dq01_detects_duplicate_pk(db):
    # SQLite's own INTEGER PRIMARY KEY constraint physically prevents a
    # duplicate from ever being inserted, so to exercise the *detection*
    # logic in dq01_pk_uniqueness() itself we rebuild `sectors` without a
    # PRIMARY KEY constraint (plain rowid-independent column) for this one
    # test, then seed a genuine duplicate sector_id.
    db.execute("DROP TABLE sectors")
    db.execute("""
        CREATE TABLE sectors (
            sector_id   INTEGER,
            sector_code TEXT,
            sector_name TEXT
        )
    """)
    db.execute("INSERT INTO sectors (sector_id, sector_code, sector_name) VALUES (99, 'X', 'Sector X')")
    db.execute("INSERT INTO sectors (sector_id, sector_code, sector_name) VALUES (99, 'Y', 'Sector Y')")
    db.commit()
    violations = validator.dq01_pk_uniqueness(db)
    assert any(v["rule_id"] == "DQ-01" and v["severity"] == "CRITICAL" and v["table"] == "sectors" for v in violations)


# ---------------------------------------------------------------------
# DQ-02 — composite (company_id, year) uniqueness
# ---------------------------------------------------------------------

def test_dq02_no_violation_on_clean_data(db):
    cid, = _seed_sector_and_companies(db, n=1)
    db.execute("INSERT INTO profitandloss (company_id, year, sales) VALUES (?, 2023, 100)", (cid,))
    db.commit()
    assert validator.dq02_composite_year_pk(db) == []


def test_dq02_detects_duplicate_company_year(db):
    cid, = _seed_sector_and_companies(db, n=1)
    # UNIQUE(company_id, year) constraint would block this at the DB level,
    # so we drop into raw SQL with an UPSERT-bypassing INSERT OR IGNORE,
    # then force a genuine duplicate via two different tables sharing a
    # detection codepath isn't applicable here -- instead, verify on a
    # table where we craft the schema-level UNIQUE around it: financial_ratios.
    db.execute("INSERT INTO profitandloss (company_id, year, sales) VALUES (?, 2023, 100)", (cid,))
    db.commit()
    with pytest.raises(sqlite3.IntegrityError):
        db.execute("INSERT INTO profitandloss (company_id, year, sales) VALUES (?, 2023, 200)", (cid,))


def test_dq02_flags_rows_inserted_around_unique_constraint(db):
    # To genuinely test the *detection* logic (not just rely on the schema's
    # own UNIQUE constraint), seed two rows that violate (company_id, year)
    # uniqueness in a table that has no UNIQUE constraint defined: `analysis`
    # doesn't carry a year column, so instead disable the constraint by
    # recreating profitandloss without it for this one test.
    db.execute("DROP TABLE profitandloss")
    db.execute("""
        CREATE TABLE profitandloss (
            pl_id INTEGER PRIMARY KEY AUTOINCREMENT,
            company_id INTEGER NOT NULL,
            year INTEGER NOT NULL,
            sales REAL
        )
    """)
    cid, = _seed_sector_and_companies(db, n=1)
    db.execute("INSERT INTO profitandloss (company_id, year, sales) VALUES (?, 2023, 100)", (cid,))
    db.execute("INSERT INTO profitandloss (company_id, year, sales) VALUES (?, 2023, 200)", (cid,))
    db.commit()
    violations = validator.dq02_composite_year_pk(db)
    assert any(v["rule_id"] == "DQ-02" and v["severity"] == "CRITICAL" for v in violations)


# ---------------------------------------------------------------------
# DQ-03 — FK integrity
# ---------------------------------------------------------------------

def test_dq03_no_violation_when_fks_valid(db):
    _seed_sector_and_companies(db, n=1)
    assert validator.dq03_fk_integrity(db) == []


def test_dq03_detects_orphaned_foreign_key(db):
    _seed_sector_and_companies(db, n=1)
    db.execute("PRAGMA foreign_keys = OFF;")
    db.execute("INSERT INTO profitandloss (company_id, year, sales) VALUES (9999, 2023, 100)")
    db.commit()
    violations = validator.dq03_fk_integrity(db)
    assert any(v["rule_id"] == "DQ-03" and v["severity"] == "CRITICAL" for v in violations)


# ---------------------------------------------------------------------
# DQ-04 — BS total balance within tolerance
# ---------------------------------------------------------------------

def test_dq04_no_violation_when_balanced(db):
    cid, = _seed_sector_and_companies(db, n=1)
    db.execute(
        "INSERT INTO balancesheet (company_id, year, total_assets, total_liabilities) VALUES (?, 2023, 1000, 1000)",
        (cid,),
    )
    db.commit()
    assert validator.dq04_bs_balance(db) == []


def test_dq04_detects_mismatch_beyond_tolerance(db):
    cid, = _seed_sector_and_companies(db, n=1)
    db.execute(
        "INSERT INTO balancesheet (company_id, year, total_assets, total_liabilities) VALUES (?, 2023, 1000, 1200)",
        (cid,),
    )
    db.commit()
    violations = validator.dq04_bs_balance(db)
    assert any(v["rule_id"] == "DQ-04" and v["severity"] == "WARNING" for v in violations)


# ---------------------------------------------------------------------
# DQ-05 — OPM cross-check
# ---------------------------------------------------------------------

def test_dq05_no_violation_when_opm_matches(db):
    cid, = _seed_sector_and_companies(db, n=1)
    db.execute(
        "INSERT INTO profitandloss (company_id, year, sales, operating_profit, opm_percent) VALUES (?, 2023, 1000, 200, 20.0)",
        (cid,),
    )
    db.commit()
    assert validator.dq05_opm_crosscheck(db) == []


def test_dq05_detects_opm_mismatch(db):
    cid, = _seed_sector_and_companies(db, n=1)
    db.execute(
        "INSERT INTO profitandloss (company_id, year, sales, operating_profit, opm_percent) VALUES (?, 2023, 1000, 200, 50.0)",
        (cid,),
    )
    db.commit()
    violations = validator.dq05_opm_crosscheck(db)
    assert any(v["rule_id"] == "DQ-05" and v["severity"] == "WARNING" for v in violations)


# ---------------------------------------------------------------------
# DQ-06 — positive sales
# ---------------------------------------------------------------------

def test_dq06_no_violation_for_positive_sales(db):
    cid, = _seed_sector_and_companies(db, n=1)
    db.execute("INSERT INTO profitandloss (company_id, year, sales) VALUES (?, 2023, 500)", (cid,))
    db.commit()
    assert validator.dq06_positive_sales(db) == []


def test_dq06_detects_non_positive_sales(db):
    cid, = _seed_sector_and_companies(db, n=1)
    db.execute("INSERT INTO profitandloss (company_id, year, sales) VALUES (?, 2023, -50)", (cid,))
    db.commit()
    violations = validator.dq06_positive_sales(db)
    assert any(v["rule_id"] == "DQ-06" and v["severity"] == "WARNING" for v in violations)


# ---------------------------------------------------------------------
# DQ-07 — net cash flow reconciliation
# ---------------------------------------------------------------------

def test_dq07_no_violation_when_reconciled(db):
    cid, = _seed_sector_and_companies(db, n=1)
    db.execute(
        "INSERT INTO cashflow (company_id, year, cash_from_operating, cash_from_investing, cash_from_financing, net_cash_flow) "
        "VALUES (?, 2023, 100, -30, -20, 50)",
        (cid,),
    )
    db.commit()
    assert validator.dq07_net_cash_reconciliation(db) == []


def test_dq07_detects_unreconciled_net_cash(db):
    cid, = _seed_sector_and_companies(db, n=1)
    db.execute(
        "INSERT INTO cashflow (company_id, year, cash_from_operating, cash_from_investing, cash_from_financing, net_cash_flow) "
        "VALUES (?, 2023, 100, -30, -20, 999)",
        (cid,),
    )
    db.commit()
    violations = validator.dq07_net_cash_reconciliation(db)
    assert any(v["rule_id"] == "DQ-07" and v["severity"] == "CRITICAL" for v in violations)


# ---------------------------------------------------------------------
# DQ-08 — tax rate sanity
# ---------------------------------------------------------------------

def test_dq08_no_violation_for_sane_tax_rate(db):
    cid, = _seed_sector_and_companies(db, n=1)
    db.execute("INSERT INTO profitandloss (company_id, year, profit_before_tax, tax) VALUES (?, 2023, 1000, 250)", (cid,))
    db.commit()
    assert validator.dq08_tax_rate_sanity(db) == []


def test_dq08_detects_implausible_tax_rate(db):
    cid, = _seed_sector_and_companies(db, n=1)
    db.execute("INSERT INTO profitandloss (company_id, year, profit_before_tax, tax) VALUES (?, 2023, 1000, 900)", (cid,))
    db.commit()
    violations = validator.dq08_tax_rate_sanity(db)
    assert any(v["rule_id"] == "DQ-08" and v["severity"] == "WARNING" for v in violations)


# ---------------------------------------------------------------------
# DQ-09 — dividend cap
# ---------------------------------------------------------------------

def test_dq09_no_violation_under_cap(db):
    cid, = _seed_sector_and_companies(db, n=1)
    db.execute(
        "INSERT INTO analysis (company_id, metric_name, metric_value) VALUES (?, 'corporate_action:Dividend', '10%')",
        (cid,),
    )
    db.commit()
    assert validator.dq09_dividend_cap(db) == []


def test_dq09_detects_dividend_above_cap(db):
    cid, = _seed_sector_and_companies(db, n=1)
    db.execute(
        "INSERT INTO analysis (company_id, metric_name, metric_value) VALUES (?, 'corporate_action:Dividend', '40%')",
        (cid,),
    )
    db.commit()
    violations = validator.dq09_dividend_cap(db)
    assert any(v["rule_id"] == "DQ-09" and v["severity"] == "WARNING" for v in violations)


# ---------------------------------------------------------------------
# DQ-10 — document URL format
# ---------------------------------------------------------------------

def test_dq10_no_violation_for_valid_url(db):
    cid, = _seed_sector_and_companies(db, n=1)
    db.execute("INSERT INTO documents (company_id, doc_type, doc_url) VALUES (?, 'annual_report', 'https://example.com/ar.pdf')", (cid,))
    db.commit()
    assert validator.dq10_url_format(db) == []


def test_dq10_detects_malformed_url(db):
    cid, = _seed_sector_and_companies(db, n=1)
    db.execute("INSERT INTO documents (company_id, doc_type, doc_url) VALUES (?, 'annual_report', 'not-a-url')", (cid,))
    db.commit()
    violations = validator.dq10_url_format(db)
    assert any(v["rule_id"] == "DQ-10" and v["severity"] == "WARNING" for v in violations)


# ---------------------------------------------------------------------
# DQ-11 — EPS sign consistency
# ---------------------------------------------------------------------

def test_dq11_no_violation_when_signs_match(db):
    cid, = _seed_sector_and_companies(db, n=1)
    db.execute("INSERT INTO profitandloss (company_id, year, net_profit, eps) VALUES (?, 2023, 500, 5.0)", (cid,))
    db.commit()
    assert validator.dq11_eps_sign(db) == []


def test_dq11_detects_sign_inconsistency(db):
    cid, = _seed_sector_and_companies(db, n=1)
    db.execute("INSERT INTO profitandloss (company_id, year, net_profit, eps) VALUES (?, 2023, -500, 5.0)", (cid,))
    db.commit()
    violations = validator.dq11_eps_sign(db)
    assert any(v["rule_id"] == "DQ-11" and v["severity"] == "WARNING" for v in violations)


# ---------------------------------------------------------------------
# DQ-12 — BS component balance (internal arithmetic)
# ---------------------------------------------------------------------

def test_dq12_no_violation_when_components_sum_correctly(db):
    cid, = _seed_sector_and_companies(db, n=1)
    db.execute(
        "INSERT INTO balancesheet (company_id, year, equity_capital, reserves, borrowings, other_liabilities, total_liabilities) "
        "VALUES (?, 2023, 100, 200, 300, 400, 1000)",
        (cid,),
    )
    db.commit()
    assert validator.dq12_bs_component_balance(db) == []


def test_dq12_detects_component_arithmetic_mismatch(db):
    cid, = _seed_sector_and_companies(db, n=1)
    db.execute(
        "INSERT INTO balancesheet (company_id, year, equity_capital, reserves, borrowings, other_liabilities, total_liabilities) "
        "VALUES (?, 2023, 100, 200, 300, 400, 5000)",
        (cid,),
    )
    db.commit()
    violations = validator.dq12_bs_component_balance(db)
    assert any(v["rule_id"] == "DQ-12" and v["severity"] == "CRITICAL" for v in violations)


# ---------------------------------------------------------------------
# DQ-13 — year range validity
# ---------------------------------------------------------------------

def test_dq13_no_violation_for_valid_year(db):
    cid, = _seed_sector_and_companies(db, n=1)
    db.execute("INSERT INTO profitandloss (company_id, year, sales) VALUES (?, 2023, 100)", (cid,))
    db.commit()
    assert validator.dq13_year_range(db) == []


def test_dq13_detects_out_of_range_year(db):
    cid, = _seed_sector_and_companies(db, n=1)
    db.execute("INSERT INTO profitandloss (company_id, year, sales) VALUES (?, 1850, 100)", (cid,))
    db.commit()
    violations = validator.dq13_year_range(db)
    assert any(v["rule_id"] == "DQ-13" and v["severity"] == "CRITICAL" for v in violations)


# ---------------------------------------------------------------------
# DQ-14 — ticker format
# ---------------------------------------------------------------------

def test_dq14_no_violation_for_valid_ticker(db):
    _seed_sector_and_companies(db, n=1)
    assert validator.dq14_ticker_format(db) == []


def test_dq14_detects_malformed_ticker(db):
    sector_id_row = db.execute(
        "INSERT INTO sectors (sector_code, sector_name) VALUES ('FIN', 'Finance')"
    )
    sector_id = db.execute("SELECT sector_id FROM sectors").fetchone()[0]
    db.execute(
        "INSERT INTO companies (ticker, company_name, sector_id) VALUES (?, 'Bad Ticker Co', ?)",
        ("bad ticker!", sector_id),
    )
    db.commit()
    violations = validator.dq14_ticker_format(db)
    assert any(v["rule_id"] == "DQ-14" and v["severity"] == "CRITICAL" for v in violations)


# ---------------------------------------------------------------------
# DQ-15 — mandatory non-null fields
# ---------------------------------------------------------------------

def test_dq15_no_violation_when_fields_populated(db):
    cid, = _seed_sector_and_companies(db, n=1)
    db.execute("INSERT INTO profitandloss (company_id, year, sales) VALUES (?, 2023, 100)", (cid,))
    db.commit()
    assert validator.dq15_mandatory_fields(db) == []


def test_dq15_detects_null_mandatory_field(db):
    cid, = _seed_sector_and_companies(db, n=1)
    db.execute("INSERT INTO profitandloss (company_id, year, sales) VALUES (?, 2023, NULL)", (cid,))
    db.commit()
    violations = validator.dq15_mandatory_fields(db)
    assert any(v["rule_id"] == "DQ-15" and v["severity"] == "CRITICAL" and v["table"] == "profitandloss" for v in violations)


# ---------------------------------------------------------------------
# DQ-16 — year coverage (<5 years flags for manual review)
# ---------------------------------------------------------------------

def test_dq16_no_violation_with_sufficient_coverage(db):
    cid, = _seed_sector_and_companies(db, n=1)
    for year in range(2018, 2024):  # 6 years
        db.execute("INSERT INTO profitandloss (company_id, year, sales) VALUES (?, ?, 100)", (cid, year))
    db.commit()
    assert validator.dq16_year_coverage(db) == []


def test_dq16_detects_sparse_year_coverage(db):
    cid, = _seed_sector_and_companies(db, n=1)
    for year in (2022, 2023):  # only 2 years, < MIN_YEAR_COVERAGE (5)
        db.execute("INSERT INTO profitandloss (company_id, year, sales) VALUES (?, ?, 100)", (cid, year))
    db.commit()
    violations = validator.dq16_year_coverage(db)
    assert any(v["rule_id"] == "DQ-16" and v["severity"] == "WARNING" for v in violations)


# ---------------------------------------------------------------------
# run_all() integration
# ---------------------------------------------------------------------

def test_run_all_returns_dataframe_with_expected_columns(db, tmp_path, monkeypatch):
    cid, = _seed_sector_and_companies(db, n=1)
    db.execute("INSERT INTO profitandloss (company_id, year, sales) VALUES (?, 2023, 100)", (cid,))
    db.commit()

    # run_all() opens its own connection from a db_path, so persist this
    # in-memory db's schema + data to a temp file first.
    tmp_db_path = tmp_path / "validator_test.db"
    file_conn = sqlite3.connect(tmp_db_path)
    db.backup(file_conn)
    file_conn.close()

    monkeypatch.setattr(validator, "OUTPUT_DIR", tmp_path)
    result = validator.run_all(db_path=tmp_db_path)

    expected_cols = {"rule_id", "severity", "table", "company_id", "year", "field", "message"}
    assert expected_cols.issubset(set(result.columns))
    assert (tmp_path / "validation_failures.csv").exists()


def test_run_all_zero_critical_on_real_project_db():
    """Sanity check against the actual project database: per the Day 05
    exit criteria, the real nifty100.db should have zero CRITICAL DQ
    violations once the pipeline has been run."""
    real_db_path = validator.PROJECT_ROOT / "nifty100.db"
    if not real_db_path.exists():
        pytest.skip("nifty100.db not present (run `make load` first)")
    result = validator.run_all(db_path=real_db_path)
    critical = result[result["severity"] == "CRITICAL"]
    assert len(critical) == 0, f"Unexpected CRITICAL violations:\n{critical}"
