"""
tests/etl/test_normaliser.py
Sprint 1 · Day 02 — 35+ unit tests for normaliser.py
  - 20 tests for normalize_year()
  - 15 tests for normalize_ticker()
"""

import pytest

from src.etl.normaliser import (
    NormalisationError,
    normalize_numeric,
    normalize_ticker,
    normalize_year,
)


# =======================================================================
# normalize_year — 20 tests
# =======================================================================

class TestNormalizeYear:

    def test_plain_int(self):
        assert normalize_year(2023) == 2023

    def test_plain_int_string(self):
        assert normalize_year("2023") == 2023

    def test_float_integer_value(self):
        assert normalize_year(2023.0) == 2023

    def test_float_non_integer_raises(self):
        with pytest.raises(NormalisationError):
            normalize_year(2023.5)

    def test_fy_two_digit(self):
        assert normalize_year("FY23") == 2023

    def test_fy_lowercase(self):
        assert normalize_year("fy23") == 2023

    def test_fy_with_space(self):
        assert normalize_year("FY 2023") == 2023

    def test_fy_four_digit(self):
        assert normalize_year("FY2023") == 2023

    def test_fy_range_two_digit(self):
        # FY23-24 refers to the year ending Mar 2024
        assert normalize_year("FY23-24") == 2024

    def test_fy_range_with_spaces(self):
        assert normalize_year("FY 23 - 24") == 2024

    def test_year_range_four_then_two_digit(self):
        assert normalize_year("2022-23") == 2023

    def test_year_range_slash(self):
        assert normalize_year("2022/23") == 2023

    def test_month_year_abbreviated(self):
        assert normalize_year("Mar-23") == 2023

    def test_month_year_full(self):
        assert normalize_year("March 2023") == 2023

    def test_month_year_space(self):
        assert normalize_year("Mar 2023") == 2023

    def test_whitespace_stripped(self):
        assert normalize_year("  2023  ") == 2023

    def test_none_raises(self):
        with pytest.raises(NormalisationError):
            normalize_year(None)

    def test_empty_string_raises(self):
        with pytest.raises(NormalisationError):
            normalize_year("")

    def test_garbage_string_raises(self):
        with pytest.raises(NormalisationError):
            normalize_year("not-a-year")

    def test_out_of_range_too_old_raises(self):
        with pytest.raises(NormalisationError):
            normalize_year(1899)

    def test_out_of_range_too_future_raises(self):
        with pytest.raises(NormalisationError):
            normalize_year(2999)

    def test_two_digit_pivot_low(self):
        # tokens 00-49 map to 2000-2049
        assert normalize_year("FY05") == 2005

    def test_two_digit_pivot_high(self):
        # tokens 50-99 map to 1950-1999
        assert normalize_year("FY95") == 1995


# =======================================================================
# normalize_ticker — 15 tests
# =======================================================================

class TestNormalizeTicker:

    def test_already_clean(self):
        assert normalize_ticker("TCS") == "TCS"

    def test_lowercase_uppercased(self):
        assert normalize_ticker("tcs") == "TCS"

    def test_mixed_case(self):
        assert normalize_ticker("TaTaMotors") == "TATAMOTORS"

    def test_strips_whitespace(self):
        assert normalize_ticker("  TCS  ") == "TCS"

    def test_strips_ns_suffix(self):
        assert normalize_ticker("TCS.NS") == "TCS"

    def test_strips_bo_suffix(self):
        assert normalize_ticker("RELIANCE.BO") == "RELIANCE"

    def test_strips_nse_suffix(self):
        assert normalize_ticker("INFY.NSE") == "INFY"

    def test_strips_bse_suffix(self):
        assert normalize_ticker("INFY.BSE") == "INFY"

    def test_lowercase_with_suffix_and_whitespace(self):
        assert normalize_ticker(" infy.ns ") == "INFY"

    def test_collapses_internal_whitespace(self):
        assert normalize_ticker("TC S") == "TCS"

    def test_allows_ampersand(self):
        assert normalize_ticker("M&M") == "M&M"

    def test_allows_hyphen(self):
        assert normalize_ticker("L-T") == "L-T"

    def test_none_raises(self):
        with pytest.raises(NormalisationError):
            normalize_ticker(None)

    def test_empty_string_raises(self):
        with pytest.raises(NormalisationError):
            normalize_ticker("")

    def test_non_string_type_raises(self):
        with pytest.raises(NormalisationError):
            normalize_ticker(12345)

    def test_invalid_characters_raise(self):
        with pytest.raises(NormalisationError):
            normalize_ticker("TCS@#$")

    def test_too_long_raises(self):
        with pytest.raises(NormalisationError):
            normalize_ticker("A" * 25)

    def test_empty_after_suffix_strip_raises(self):
        with pytest.raises(NormalisationError):
            normalize_ticker(".NS")


# =======================================================================
# normalize_numeric — bonus coverage tests
# =======================================================================

class TestNormalizeNumeric:

    def test_int_passthrough(self):
        assert normalize_numeric(100) == 100.0

    def test_float_passthrough(self):
        assert normalize_numeric(100.5) == 100.5

    def test_string_with_commas(self):
        assert normalize_numeric("1,234.5") == 1234.5

    def test_none_returns_none(self):
        assert normalize_numeric(None) is None

    def test_dash_returns_none(self):
        assert normalize_numeric("-") is None

    def test_na_returns_none(self):
        assert normalize_numeric("NA") is None

    def test_invalid_string_raises(self):
        with pytest.raises(NormalisationError):
            normalize_numeric("abc")
