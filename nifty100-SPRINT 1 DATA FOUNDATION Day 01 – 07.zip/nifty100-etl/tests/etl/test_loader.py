"""
tests/etl/test_loader.py
Sprint 1 · Day 02 / Day 05 — unit tests for src/etl/loader.py

Runs run_full_load() once against a temporary database file (so the
project's real nifty100.db is never touched by the test suite) and then
asserts on the resulting state: row counts per table, zero FK violations,
zero CRITICAL rejections in the audit, and a few spot-checks on
normalisation behaviour (ticker uppercasing/uniqueness, sector linkage).

The fixture is session-scoped because a full load takes a couple of
seconds and every test in this module reads from the same loaded state.
"""

from __future__ import annotations

import sqlite3
from pathlib import Path

import pytest

from src.etl import loader


@pytest.fixture(scope="module")
def loaded_db(tmp_path_factory):
    """Run the full Day 05 load against a throwaway db file and yield
    (audits, db_path) for the whole test module."""
    tmp_dir = tmp_path_factory.mktemp("nifty100_test_db")
    db_path = tmp_dir / "nifty100_test.db"
    audits = loader.run_full_load(db_path=db_path)
    yield audits, db_path


@pytest.fixture(scope="module")
def conn(loaded_db):
    _, db_path = loaded_db
    c = sqlite3.connect(db_path)
    c.execute("PRAGMA foreign_keys = ON;")
    yield c
    c.close()


def _count(conn, table: str) -> int:
    return conn.execute(f"SELECT COUNT(*) FROM {table}").fetchone()[0]


# ---------------------------------------------------------------------
# Row count targets (Day 05 exit criteria)
# ---------------------------------------------------------------------

def test_companies_count_is_92(conn):
    assert _count(conn, "companies") == 92


def test_sectors_loaded(conn):
    assert _count(conn, "sectors") == 12


def test_stock_prices_count_is_5520(conn):
    assert _count(conn, "stock_prices") == 5520


def test_profitandloss_row_count_near_target(conn):
    n = _count(conn, "profitandloss")
    assert 1200 <= n <= 1350, f"P&L row count {n} far from ~1276 target"


def test_balancesheet_row_count_near_target(conn):
    n = _count(conn, "balancesheet")
    assert 1200 <= n <= 1400, f"BS row count {n} far from ~1312 target"


def test_cashflow_row_count_near_target(conn):
    n = _count(conn, "cashflow")
    assert 1100 <= n <= 1300, f"CF row count {n} far from ~1187 target"


def test_profitandloss_and_balancesheet_and_cashflow_nonempty(conn):
    for table in ("profitandloss", "balancesheet", "cashflow"):
        assert _count(conn, table) > 0


# ---------------------------------------------------------------------
# Foreign key / referential integrity (Day 05 exit criteria)
# ---------------------------------------------------------------------

def test_foreign_key_check_zero_violations(conn):
    violations = conn.execute("PRAGMA foreign_key_check;").fetchall()
    assert violations == []


def test_every_company_has_valid_sector(conn):
    rows = conn.execute(
        "SELECT c.company_id FROM companies c "
        "LEFT JOIN sectors s ON c.sector_id = s.sector_id "
        "WHERE c.sector_id IS NOT NULL AND s.sector_id IS NULL"
    ).fetchall()
    assert rows == []


def test_profitandloss_company_ids_all_exist(conn):
    rows = conn.execute(
        "SELECT pl.company_id FROM profitandloss pl "
        "LEFT JOIN companies c ON pl.company_id = c.company_id "
        "WHERE c.company_id IS NULL"
    ).fetchall()
    assert rows == []


# ---------------------------------------------------------------------
# Normalisation spot-checks (ticker uppercasing / uniqueness)
# ---------------------------------------------------------------------

def test_tickers_are_uppercase(conn):
    tickers = [r[0] for r in conn.execute("SELECT ticker FROM companies").fetchall()]
    assert all(t == t.upper() for t in tickers)


def test_tickers_are_unique(conn):
    tickers = [r[0] for r in conn.execute("SELECT ticker FROM companies").fetchall()]
    assert len(tickers) == len(set(tickers))


def test_company_names_non_null(conn):
    rows = conn.execute(
        "SELECT COUNT(*) FROM companies WHERE company_name IS NULL OR TRIM(company_name) = ''"
    ).fetchone()
    assert rows[0] == 0


# ---------------------------------------------------------------------
# Audit output (Day 05 exit criteria: zero CRITICAL rejections)
# ---------------------------------------------------------------------

def test_audit_rows_cover_all_twelve_source_files(loaded_db):
    audits, _ = loaded_db
    source_files = {a.source_file for a in audits}
    expected = {
        "sectors.xlsx", "companies_master.xlsx", "profit_and_loss.xlsx",
        "balance_sheet.xlsx", "cash_flow.xlsx", "stock_prices.xlsx",
        "analysis_notes.xlsx", "shareholding_pattern.xlsx", "corporate_actions.xlsx",
        "company_documents.xlsx", "pros_and_cons.xlsx", "peer_groups.xlsx",
    }
    assert expected.issubset(source_files)


def test_audit_has_zero_critical_rejections(loaded_db):
    audits, _ = loaded_db
    critical = [a for a in audits if a.rows_rejected > 0]
    assert critical == [], f"Unexpected rejections: {critical}"


def test_load_audit_csv_written(loaded_db):
    assert (loader.OUTPUT_DIR / "load_audit.csv").exists()


def test_load_audit_summary_written(loaded_db):
    assert (loader.OUTPUT_DIR / "load_audit_summary.txt").exists()


# ---------------------------------------------------------------------
# Schema sanity
# ---------------------------------------------------------------------

def test_all_eleven_tables_exist(conn):
    tables = {
        r[0] for r in conn.execute(
            "SELECT name FROM sqlite_master WHERE type='table'"
        ).fetchall()
    }
    expected = {
        "companies", "profitandloss", "balancesheet", "cashflow", "analysis",
        "documents", "prosandcons", "sectors", "stock_prices",
        "financial_ratios", "peer_groups",
    }
    assert expected.issubset(tables)


def test_pragma_foreign_keys_is_on(conn):
    assert conn.execute("PRAGMA foreign_keys;").fetchone()[0] == 1
